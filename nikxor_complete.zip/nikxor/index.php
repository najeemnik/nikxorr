<?php
/**
 * NiKXor - Mobile Shop Management System
 * Main Executive Dashboard
 * URL: http://localhost/nikxor/index.php
 */

$pageTitle = 'داشبورد عمومی دکان';
require_once __DIR__ . '/includes/header.php';

// Calculate core metrics
$metrics = get_dashboard_metrics();

// Fetch low stock items (quantity <= 3)
$lowStockStmt = $pdo->query("SELECT s.*, c.name as category_name 
                             FROM stock s 
                             LEFT JOIN categories c ON s.category_id = c.id 
                             WHERE s.quantity <= 3 
                             ORDER BY s.quantity ASC LIMIT 6");
$lowStockItems = $lowStockStmt->fetchAll();

// Fetch Mudaraba contracts for dashboard display
$mudarabaContracts = $pdo->query("SELECT * FROM mudaraba_contracts ORDER BY id DESC")->fetchAll();
$totalMudarabaActiveCap = 0;
$totalMudarabaSales = 0;
$totalMudarabaShopProfit = 0;
$activeMudarabaCount = 0;
foreach ($mudarabaContracts as $mc) {
    if ($mc['status'] === 'active') {
        $totalMudarabaActiveCap += (float)$mc['capital_amount'];
        $activeMudarabaCount++;
    }
    $totalMudarabaSales += (float)$mc['total_sales_amount'];
    $totalMudarabaShopProfit += ((float)$mc['total_profit_amount'] * (float)$mc['shop_profit_rate']) / 100;
}

// Fetch latest sales (last 6 transactions)
$recentSalesStmt = $pdo->query("SELECT s.*, u.fullname as staff_name 
                                FROM sales s 
                                LEFT JOIN users u ON s.created_by = u.id 
                                ORDER BY s.id DESC LIMIT 6");
$recentSales = $recentSalesStmt->fetchAll();
?>

<!-- Metric Statistics Cards -->
<div class="stats-grid">
    <!-- Card 1: مجموع ارزش گدام (خریداری) -->
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مجموع ارزش گدام (خریداری)</span>
            <div class="stat-icon icon-stock">
                <i class="fa-solid fa-boxes-stacked"></i>
            </div>
        </div>
        <div class="stat-value"><?= format_money($metrics['stock_value']) ?></div>
        <div class="stat-desc">
            <i class="fa-solid fa-layer-group ml-1"></i> مجموع <?= to_persian_num($metrics['total_items_count']) ?> قلم جنس در دکان
        </div>
    </div>

    <!-- Card 2: سرمایه مضاربت و کالای خارجی (کنار مجموع ارزش گدام) -->
    <div class="stat-card" style="border-right: 4px solid #10b981;">
        <div class="stat-header">
            <span class="stat-title">سرمایه مضاربت (کالای خارجی)</span>
            <div class="stat-icon" style="background: rgba(16, 185, 129, 0.15); color: #10b981;">
                <i class="fa-solid fa-handshake-angle"></i>
            </div>
        </div>
        <div class="stat-value" style="color: #059669;"><?= format_money($totalMudarabaActiveCap) ?></div>
        <div class="stat-desc" style="display: flex; justify-content: space-between; align-items: center;">
            <span><i class="fa-solid fa-globe ml-1"></i> <?= to_persian_num($activeMudarabaCount) ?> شریک و پروژه فعال</span>
            <a href="<?= BASE_URL ?>modules/mudaraba.php" style="color: #0284c7; font-weight: 700; text-decoration: none; font-size: 11.5px;">
                مدیریت <i class="fa-solid fa-arrow-left"></i>
            </a>
        </div>
    </div>

    <!-- Card 3: سرمایه عمومی -->
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">سرمایه عمومی دکان</span>
            <div class="stat-icon icon-capital">
                <i class="fa-solid fa-vault"></i>
            </div>
        </div>
        <div class="stat-value"><?= format_money($metrics['total_capital']) ?></div>
        <div class="stat-desc">
            <i class="fa-solid fa-building-columns ml-1"></i> سرمایه ثبت شده دکان
        </div>
    </div>

    <!-- Card 4: فروشات امروز -->
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">فروشات امروز</span>
            <div class="stat-icon icon-sales">
                <i class="fa-solid fa-cart-shopping"></i>
            </div>
        </div>
        <div class="stat-value"><?= format_money($metrics['today_sales']) ?></div>
        <div class="stat-desc">
            <i class="fa-regular fa-calendar ml-1"></i> تاریخ: <?= to_persian_num(date('Y/m/d')) ?>
        </div>
    </div>

    <!-- Card 5: مفاد خالص امروز -->
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مفاد خالص امروز</span>
            <div class="stat-icon icon-profit">
                <i class="fa-solid fa-arrow-trend-up"></i>
            </div>
        </div>
        <div class="stat-value" style="color: <?= $metrics['today_net_profit'] >= 0 ? '#15803d' : '#b91c1c' ?>;">
            <?= format_money($metrics['today_net_profit']) ?>
        </div>
        <div class="stat-desc">
            مفاد فروشات امروز منهای مصارف
        </div>
    </div>

    <!-- Card 6: مجموع مفاد عمومی -->
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مجموع مفاد عمومی</span>
            <div class="stat-icon icon-profit">
                <i class="fa-solid fa-chart-line"></i>
            </div>
        </div>
        <div class="stat-value" style="color: <?= $metrics['overall_net_profit'] >= 0 ? '#15803d' : '#b91c1c' ?>;">
            <?= format_money($metrics['overall_net_profit']) ?>
        </div>
        <div class="stat-desc">
            مفاد ناخالص: <?= format_money($metrics['total_sales_profit']) ?>
        </div>
    </div>

    <!-- Card 7: قرضه های باقی مانده -->
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">قرضه های باقی مانده</span>
            <div class="stat-icon icon-debt">
                <i class="fa-solid fa-hand-holding-dollar"></i>
            </div>
        </div>
        <div class="stat-value" style="color: #b91c1c;">
            <?= format_money($metrics['total_outstanding_debts']) ?>
        </div>
        <div class="stat-desc">
            طلب های دکان از مشتریان بازار
        </div>
    </div>
</div>

<!-- Quick Action Shortcuts -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-bolt ml-1"></i> دسترسی سریع به عملیات های پرکاربرد
        </h3>
    </div>
    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
        <a href="<?= BASE_URL ?>modules/sales.php" class="btn btn-primary">
            <i class="fa-solid fa-cash-register"></i> فروختن جنس جدید (صدور بل)
        </a>
        <a href="<?= BASE_URL ?>modules/invoices.php" class="btn btn-secondary" style="background: #0284c7; color: white;">
            <i class="fa-solid fa-receipt"></i> آرشیف بل ها
        </a>
        <a href="<?= BASE_URL ?>modules/mudaraba.php" class="btn btn-secondary" style="background: #059669; color: white;">
            <i class="fa-solid fa-handshake-angle"></i> حساب مضاربت (کالای خارجی)
        </a>
        <a href="<?= BASE_URL ?>modules/stock_add.php" class="btn btn-secondary">
            <i class="fa-solid fa-plus-circle"></i> ثبت جنس جدید در گدام
        </a>
        <a href="<?= BASE_URL ?>modules/stock.php" class="btn btn-secondary">
            <i class="fa-solid fa-boxes-stacked"></i> لست و مدیریت اجناس
        </a>
        <a href="<?= BASE_URL ?>modules/debts.php" class="btn btn-secondary">
            <i class="fa-solid fa-file-invoice"></i> مدیریت قرضه ها و اقساط
        </a>
        <a href="<?= BASE_URL ?>modules/reports.php" class="btn btn-secondary">
            <i class="fa-solid fa-chart-pie"></i> گزارشات مالی و حسابداری
        </a>
    </div>
</div>

<!-- MUDARABA PARTNERS LIVE PANEL IN DASHBOARD -->
<div class="card" style="margin-bottom: 24px; border-top: 3px solid #10b981;">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <h3 class="card-title" style="color: #065f46;">
            <i class="fa-solid fa-handshake-angle ml-1"></i> وضعیت شرکاء و کالاهای مضاربت (تفکیک‌شده از حسابات دکان)
        </h3>
        <a href="<?= BASE_URL ?>modules/mudaraba.php" class="btn btn-sm btn-secondary">
            <i class="fa-solid fa-arrow-left ml-1"></i> مدیریت کامل و ثبت قرارداد جدید
        </a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>نام شریک مضاربت</th>
                    <th>شرح کالا و محموله</th>
                    <th>کشور مبدا</th>
                    <th style="text-align: center;">سرمایه ارائه‌شده</th>
                    <th style="text-align: center;">نسبت سود</th>
                    <th style="text-align: center;">مفاد تحقق‌یافته</th>
                    <th style="text-align: center;">سهم سود شریک</th>
                    <th style="text-align: center;">وضعیت</th>
                    <th style="text-align: center; width: 140px;">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($mudarabaContracts)): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 24px; color: #94a3b8;">
                            هنوز قرارداد مضاربتی برای واردات و شراکت در کالا ثبت نشده است. 
                            <a href="<?= BASE_URL ?>modules/mudaraba.php" style="color: #0284c7; font-weight: 700;">ثبت اولین قرارداد مضاربت</a>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach (array_slice($mudarabaContracts, 0, 5) as $mc): 
                        $pShare = ((float)$mc['total_profit_amount'] * (float)$mc['partner_profit_rate']) / 100;
                    ?>
                        <tr>
                            <td>
                                <strong><?= sanitize($mc['partner_name']) ?></strong>
                                <?php if (!empty($mc['phone'])): ?>
                                    <div style="font-size: 11px; color: #64748b;"><?= sanitize($mc['phone']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-weight: 700; color: #0f172a;"><?= sanitize($mc['project_title']) ?></span>
                            </td>
                            <td>
                                <span class="badge" style="background: #f1f5f9; color: #334155; font-size: 11.5px;">
                                    <?= sanitize($mc['country_source'] ?: 'خارجی') ?>
                                </span>
                            </td>
                            <td style="text-align: center; font-weight: 800; color: #15803d;">
                                <?= format_money($mc['capital_amount'], false) ?>
                            </td>
                            <td style="text-align: center; font-size: 12px; font-weight: 700;">
                                <?= (float)$mc['partner_profit_rate'] ?>٪ / <?= (float)$mc['shop_profit_rate'] ?>٪
                            </td>
                            <td style="text-align: center; font-weight: 800; color: #0284c7;">
                                <?= format_money($mc['total_profit_amount'], false) ?>
                            </td>
                            <td style="text-align: center; font-weight: 800; color: #7e22ce;">
                                <?= format_money($pShare, false) ?>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge badge-<?= ($mc['status'] === 'active') ? 'success' : 'secondary' ?>">
                                    <?= ($mc['status'] === 'active') ? 'فعال' : 'تسویه شده' ?>
                                </span>
                            </td>
                            <td style="text-align: center;">
                                <a href="<?= BASE_URL ?>print/mudaraba.php?id=<?= $mc['id'] ?>" target="_blank" class="btn btn-sm btn-secondary" title="چاپ و دانلود سند مضاربت">
                                    <i class="fa-solid fa-print"></i> PDF
                                </a>
                                <a href="<?= BASE_URL ?>modules/mudaraba.php" class="btn btn-sm btn-primary" title="مدیریت">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 20px;">
    <!-- Shop Status & Financial Summary (Recent invoices removed to financial reports as requested) -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa-solid fa-chart-simple ml-1"></i> وضعیت زنده نقدینگی و جریان روزانه دکان
            </h3>
            <a href="<?= BASE_URL ?>modules/reports.php" class="btn btn-sm btn-secondary">
                <i class="fa-solid fa-file-invoice"></i> مشاهده بل‌ها در گزارشات مالی
            </a>
        </div>
        <div style="padding: 10px 0;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px;">
                <div style="background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <div style="font-size: 12px; color: #64748b; margin-bottom: 4px;">فروشات ثبت شده امروز</div>
                    <div style="font-size: 18px; font-weight: 800; color: #0284c7;"><?= format_money($metrics['today_sales']) ?></div>
                    <div style="font-size: 11px; color: #10b981; margin-top: 4px;"><i class="fa-solid fa-check-circle ml-1"></i> معاملات ثبت شده</div>
                </div>
                <div style="background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <div style="font-size: 12px; color: #64748b; margin-bottom: 4px;">مانده طلبات از مشتریان</div>
                    <div style="font-size: 18px; font-weight: 800; color: #dc2626;"><?= format_money($metrics['total_outstanding_debts']) ?></div>
                    <div style="font-size: 11px; color: #eab308; margin-top: 4px;"><i class="fa-solid fa-clock ml-1"></i> قابل وصول در بازار</div>
                </div>
            </div>

            <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 10px; padding: 16px; display: flex; align-items: center; justify-content: space-between;">
                <div>
                    <h4 style="font-size: 14px; font-weight: 700; color: #1e3a8a; margin-bottom: 4px;">
                        <i class="fa-solid fa-receipt ml-1"></i> گزارشات کامل فروشات و بل‌ها
                    </h4>
                    <p style="font-size: 12.5px; color: #3b82f6; margin: 0;">
                        تاریخچه تمام بل‌ها، ساعت دقیق صدور، چاپ مجدد و جزئیات کالاها در بخش گزارشات مالی متمرکز شده است.
                    </p>
                </div>
                <a href="<?= BASE_URL ?>modules/reports.php" class="btn btn-primary btn-sm" style="white-space: nowrap;">
                    گزارشات و بل‌ها <i class="fa-solid fa-arrow-left mr-1"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Low Stock Alert Box (Lockable Feature) -->
    <div class="card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <h3 class="card-title" style="display: flex; align-items: center; gap: 6px;">
                <i class="fa-solid fa-triangle-exclamation" style="color: #b91c1c;"></i> هشدار کمبود موجودی
                <?php if (is_feature_locked('low_stock_alert')): ?>
                    <span class="badge-lock-tag" onclick="showLockModal('low_stock_alert', 'Low Stock Alert Notification', 'هشدار کمبود موجودی');">
                        <i class="fa-solid fa-lock"></i> قفل
                    </span>
                <?php endif; ?>
            </h3>
            <span class="badge badge-danger"><?= to_persian_num(count($lowStockItems)) ?> قلم</span>
        </div>

        <?php if (is_feature_locked('low_stock_alert')): ?>
            <!-- Locked Blurred View with Overlay -->
            <div class="locked-blur-wrapper">
                <div class="locked-blur-content" style="padding: 10px;">
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <div style="display: flex; justify-content: space-between; padding: 8px 10px; background-color: #f8fafc; border-radius: 6px;">
                            <div>
                                <div style="font-size: 13px; font-weight: 700;">سامسونگ گلکسی S24 الترا</div>
                                <div style="font-size: 11px; color: #64748b;">گدام اصلی دکان</div>
                            </div>
                            <span class="badge badge-danger">۱ عدد</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 8px 10px; background-color: #f8fafc; border-radius: 6px;">
                            <div>
                                <div style="font-size: 13px; font-weight: 700;">آیفون 15 پرو مکس</div>
                                <div style="font-size: 11px; color: #64748b;">قفسه ویترین</div>
                            </div>
                            <span class="badge badge-danger">۲ عدد</span>
                        </div>
                    </div>
                </div>
                <div class="locked-overlay-card">
                    <h4><i class="fa-solid fa-lock mr-1"></i> هشدار کمبود موجودی قفل می‌باشد</h4>
                    <p class="en-notice">This feature is currently locked. To request access and unlock this feature, please contact <strong>Ahmad Najeem Nik</strong>.</p>
                    <a href="https://wa.me/93783788278?text=Hello%20Ahmad%20Najeem%20Nik,%20I%20would%20like%20to%20unlock%20Low%20Stock%20Alert" target="_blank" class="btn-whatsapp-direct">
                        <i class="fa-brands fa-whatsapp"></i> واتس‌اپ احمد نجیم نیک (+93783788278)
                    </a>
                </div>
            </div>
            <div style="margin-top: 14px; text-align: center;">
                <button type="button" onclick="showLockModal('view_low_stock', 'View All Low Stock Items', 'مشاهده تمام اجناس کمبود');" class="btn btn-sm btn-secondary" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px;">
                    <i class="fa-solid fa-lock text-amber-500"></i> مشاهده تمام اجناس کمبود
                </button>
            </div>
        <?php else: ?>
            <!-- Unlocked View -->
            <?php if (empty($lowStockItems)): ?>
                <div style="text-align: center; padding: 24px 10px; color: #15803d;">
                    <i class="fa-solid fa-circle-check" style="font-size: 32px; margin-bottom: 8px;"></i>
                    <p style="font-size: 13px;">موجودی تمامی اجناس در وضعیت مطلوب قرار دارد.</p>
                </div>
            <?php else: ?>
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <?php foreach ($lowStockItems as $lItem): ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 10px; background-color: #f8fafc; border-radius: 6px; border: 1px solid #e2e8f0;">
                            <div>
                                <div style="font-size: 13px; font-weight: 700; color: #0f172a;"><?= sanitize($lItem['name']) ?></div>
                                <div style="font-size: 11px; color: #64748b;"><?= sanitize($lItem['warehouse_location'] ?? 'گدام') ?></div>
                            </div>
                            <div style="text-align: left;">
                                <span class="badge <?= $lItem['quantity'] <= 0 ? 'badge-danger' : 'badge-warning' ?>" style="font-size: 12px;">
                                    <?= to_persian_num($lItem['quantity']) ?> عدد
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top: 14px; text-align: center;">
                    <?php if (is_feature_locked('view_low_stock')): ?>
                        <button type="button" onclick="showLockModal('view_low_stock', 'View All Low Stock Items', 'مشاهده تمام اجناس کمبود');" class="btn btn-sm btn-secondary" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px;">
                            <i class="fa-solid fa-lock text-amber-500"></i> مشاهده تمام اجناس کمبود
                        </button>
                    <?php else: ?>
                        <a href="<?= BASE_URL ?>modules/stock.php?filter=low" class="btn btn-sm btn-secondary" style="width: 100%;">
                            مشاهده تمام اجناس کمبود
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>


<?php require_once __DIR__ . '/includes/footer.php'; ?>
