<?php
/**
 * NiKXor - Mobile Shop Management System
 * Standard Header Layout
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

// Enforce login for all normal application pages
auth_require();

$currentUser = auth_user();
$shopName = get_setting('shop_name', DEFAULT_SHOP_NAME);
$shopLogo = get_setting('shop_logo', '');
$activeTheme = $_SESSION['active_theme'] ?? get_setting('active_theme', 'classic');
$pageTitle = $pageTitle ?? 'سیستم مدیریت دکان';
$currentScript = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?> - <?= sanitize($shopName) ?></title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Vazirmatn Font -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
    <!-- Core Application CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css?v=<?= APP_VERSION ?>">
</head>
<body class="theme-<?= sanitize($activeTheme) ?>">

<div class="app-wrapper">
    <!-- Sidebar Navigation -->
    <aside class="app-sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon golden-aura-glow">
                <?php if (!empty($shopLogo) && file_exists(__DIR__ . '/../uploads/' . $shopLogo)): ?>
                    <img src="<?= BASE_URL ?>uploads/<?= sanitize($shopLogo) ?>" alt="<?= sanitize($shopName) ?>" style="width: 38px; height: 38px; object-fit: contain; border-radius: 6px;">
                <?php else: ?>
                    <i class="fa-solid fa-mobile-screen-button" style="color: #fbbf24;"></i>
                <?php endif; ?>
            </div>
            <div class="brand-info">
                <h1><?= sanitize($shopName) ?></h1>
                <span>سیستم مدیریت فروش و گدام</span>
            </div>
            <button type="button" id="sidebarCloseBtn" class="sidebar-close-btn" aria-label="بستن منو" title="بستن منو">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <nav class="sidebar-nav">
            <!-- 1. صفحه اصلی -->
            <a href="<?= BASE_URL ?>index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-house"></i>
                <span>صفحه اصلی</span>
            </a>

            <!-- 2. فروختن جنس و بل جدید -->
            <a href="<?= BASE_URL ?>modules/sales.php" class="nav-link <?= ($currentScript === 'sales.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-cash-register"></i>
                <span>فروختن جنس (بل جدید)</span>
            </a>

            <!-- 2.1 آرشیف بل ها -->
            <a href="<?= BASE_URL ?>modules/invoices.php" class="nav-link <?= ($currentScript === 'invoices.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-receipt" style="color: #0284c7;"></i>
                <span>آرشیف بل ها</span>
            </a>
            
            <!-- 3. گدام و اجناس -->
            <a href="<?= BASE_URL ?>modules/stock.php" class="nav-link <?= (in_array($currentScript, ['stock.php', 'stock_add.php', 'stock_edit.php', 'warehouse.php', 'categories.php'])) ? 'active' : '' ?>">
                <i class="fa-solid fa-boxes-stacked"></i>
                <span>گدام و اجناس</span>
            </a>

            <!-- 4. قرضه ها و اقساط -->
            <a href="<?= BASE_URL ?>modules/debts.php" class="nav-link <?= ($currentScript === 'debts.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-hand-holding-dollar"></i>
                <span>قرضه ها و حسابات</span>
            </a>

            <!-- 5. مشتریان (VIP و عادی) -->
            <a href="<?= BASE_URL ?>modules/customers.php" class="nav-link <?= ($currentScript === 'customers.php') ? 'active' : '' ?>" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-users"></i>
                    <span>مشتریان و حسابات</span>
                </span>
                <?php if (is_feature_locked('customers_module')): ?>
                    <span class="badge-lock-tag" style="padding: 1px 6px; font-size: 10px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                <?php endif; ?>
            </a>

            <!-- 6. مصارف دکان -->
            <a href="<?= BASE_URL ?>modules/expenses.php" class="nav-link <?= ($currentScript === 'expenses.php') ? 'active' : '' ?>" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-wallet" style="color: #0284c7;"></i>
                    <span>مصارف دکان</span>
                </span>
                <?php if (is_feature_locked('expenses_module')): ?>
                    <span class="badge-lock-tag" style="padding: 1px 6px; font-size: 10px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                <?php endif; ?>
            </a>

            <!-- 6.1 ضرر و خسارات اجناس (جداگانه) -->
            <a href="<?= BASE_URL ?>modules/losses.php" class="nav-link <?= ($currentScript === 'losses.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-triangle-exclamation" style="color: #dc2626;"></i>
                <span>ضرر و خسارات اجناس</span>
            </a>

            <!-- 7. شریک ها و سرمایه عمومی -->
            <a href="<?= BASE_URL ?>modules/partners.php" class="nav-link <?= (in_array($currentScript, ['partners.php', 'capital.php'])) ? 'active' : '' ?>">
                <i class="fa-solid fa-users-gear"></i>
                <span>شریک ها و سرمایه دکان</span>
            </a>

            <!-- 7.1 حساب اختصاصی مضاربت (کالای خارجی) -->
            <a href="<?= BASE_URL ?>modules/mudaraba.php" class="nav-link <?= ($currentScript === 'mudaraba.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-handshake-angle" style="color: #10b981;"></i>
                <span>سرمایه و مضاربت (خارجی)</span>
            </a>

            <!-- 8. گزارشات مالی -->
            <a href="<?= BASE_URL ?>modules/reports.php" class="nav-link <?= ($currentScript === 'reports.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-chart-line"></i>
                <span>گزارشات مالی</span>
            </a>

            <!-- 9. هوش مصنوعی حسابدار دکان -->
            <a href="<?= BASE_URL ?>modules/ai_advisor.php" class="nav-link <?= ($currentScript === 'ai_advisor.php') ? 'active' : '' ?>" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-wand-magic-sparkles" style="color: #38bdf8;"></i>
                    <span>هوش مصنوعی دکان</span>
                </span>
                <?php if (is_feature_locked('ai_advisor')): ?>
                    <span class="badge-lock-tag" style="padding: 1px 6px; font-size: 10px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                <?php endif; ?>
            </a>

            <!-- 10. پشتیبان‌گیری دیتابیس (بک‌آپ) -->
            <a href="<?= BASE_URL ?>modules/backup.php" class="nav-link <?= ($currentScript === 'backup.php') ? 'active' : '' ?>" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-cloud-arrow-down" style="color: #0284c7;"></i>
                    <span>پشتیبان‌گیری (بک‌آپ)</span>
                </span>
                <?php if (is_feature_locked('backup_module')): ?>
                    <span class="badge-lock-tag" style="padding: 1px 6px; font-size: 10px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                <?php endif; ?>
            </a>

            <!-- 11. درباره برنامه و سازنده -->
            <a href="<?= BASE_URL ?>modules/about.php" class="nav-link <?= ($currentScript === 'about.php') ? 'active' : '' ?>">
                <i class="fa-solid fa-circle-info" style="color: #6366f1;"></i>
                <span>درباره برنامه و سازنده</span>
            </a>

            <?php if (!empty($_SESSION['super_admin_verified']) || ($currentUser['username'] ?? '') === 'nikadmin'): ?>
                <a href="<?= BASE_URL ?>admin/secret_panel_786.php" class="nav-link" style="color: #d97706; font-weight: 700; background: rgba(251, 191, 36, 0.12); border-radius: 6px; margin-top: 6px;">
                    <i class="fa-solid fa-shield-halved" style="color: #d97706;"></i>
                    <span>کنترل پنل سوپر ادمین</span>
                </a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <div class="user-snippet">
                <div class="user-info">
                    <div class="user-avatar">
                        <i class="fa-solid fa-store"></i>
                    </div>
                    <div class="user-details">
                        <div class="user-name"><?= sanitize($currentUser['fullname']) ?></div>
                        <div class="user-role">
                            محیط عمومی دکان
                        </div>
                    </div>
                </div>
                <button type="button" onclick="lockShopScreen();" class="logout-btn" style="background: #fef3c7; color: #b45309; border: 1px solid #fde68a;" title="قفل کردن فوری صفحه دکان">
                    <i class="fa-solid fa-lock"></i>
                </button>
            </div>
        </div>
    </aside>

    <!-- Mobile Drawer Overlay -->
    <div id="mobileNavOverlay" class="mobile-overlay"></div>

    <!-- Main Content Area -->
    <main class="app-main">
        <header class="app-topbar">
            <div class="page-title" style="display: flex; align-items: center; gap: 10px;">
                <button type="button" id="mobileMenuToggle" class="mobile-menu-toggle" aria-label="باز کردن منو" title="منوی دکان">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <?php if (!empty($shopLogo) && file_exists(__DIR__ . '/../uploads/' . $shopLogo)): ?>
                    <div class="golden-aura-glow" style="width: 32px; height: 32px;">
                        <img src="<?= BASE_URL ?>uploads/<?= sanitize($shopLogo) ?>" alt="Logo" style="width: 28px; height: 28px; object-fit: contain;">
                    </div>
                <?php endif; ?>
                <h2><?= sanitize($pageTitle) ?></h2>
            </div>
            <div class="topbar-actions" style="display: flex; align-items: center; gap: 8px;">
                <?php if (!empty($_SESSION['super_admin_verified']) || ($currentUser['username'] ?? '') === 'nikadmin'): ?>
                    <a href="<?= BASE_URL ?>admin/secret_panel_786.php" class="btn btn-sm btn-super-admin" style="background: #f59e0b; color: #0f172a; font-weight: 700; border: none; box-shadow: 0 2px 6px rgba(245, 158, 11, 0.3);" title="پنل محرمانه سوپر ادمین">
                        <i class="fa-solid fa-shield-halved"></i> <span class="mobile-hide-text">سوپر ادمین</span>
                    </a>
                <?php endif; ?>
                <span class="badge badge-secondary topbar-clock">
                    <i class="fa-regular fa-clock ml-1"></i> <?= date('Y/m/d H:i') ?>
                </span>
                <a href="<?= BASE_URL ?>modules/sales.php" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-cart-plus"></i> <span class="mobile-hide-text">فروختن سریع</span>
                </a>
                <!-- Screen Lock Button (Shopkeeper Security) -->
                <button type="button" onclick="lockShopScreen();" class="btn btn-sm" style="background: #fef3c7; color: #92400e; border: 1.5px solid #f59e0b; font-weight: 800; display: inline-flex; align-items: center; gap: 6px;" title="قفل کردن فوری صفحه دکان">
                    <i class="fa-solid fa-lock"></i>
                    <span class="mobile-hide-text">قفل صفحه</span>
                </button>
                <button type="button" onclick="openScreenLockSettingsModal();" class="btn btn-sm btn-secondary" style="background: #ffffff; color: #475569; border: 1px solid #cbd5e1; padding: 6px 10px;" title="تنظیم پین‌کد قفل صفحه (دلخواه دکاندار)">
                    <i class="fa-solid fa-key"></i>
                </button>
            </div>
        </header>

        <div class="app-content">

            <?php 
            $flash = get_flash();
            if ($flash): 
            ?>
                <div class="alert alert-<?= sanitize($flash['type']) ?>">
                    <i class="fa-solid fa-circle-info"></i>
                    <span><?= sanitize($flash['text']) ?></span>
                </div>
            <?php endif; ?>
