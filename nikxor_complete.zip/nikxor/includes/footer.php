        </div> <!-- End app-content -->
    </main>
</div> <!-- End app-wrapper -->

<!-- Universal Feature Lock Modal (Ahmad Najeem Nik Contact) -->
<div id="featureLockModal" class="feature-modal-backdrop" onclick="if(event.target === this) closeLockModal();">
    <div class="feature-modal-box">
        <button type="button" class="feature-modal-close" onclick="closeLockModal();" aria-label="Close">&times;</button>
        
        <div class="feature-modal-icon">
            <i class="fa-solid fa-lock"></i>
        </div>

        <h3 id="lockModalTitleFa" class="feature-modal-title">این گزینه قفل می‌باشد</h3>
        <p id="lockModalSubtitle" class="feature-modal-subtitle">جهت درخواست و بازگشایی این بخش با احمد نجیم نیک تماس بگیرید</p>

        <div class="feature-modal-en-box">
            <h5 id="lockModalTitleEn">Feature Locked</h5>
            <p>This feature is currently locked. To request access and unlock this feature, please contact <strong>Ahmad Najeem Nik</strong>.</p>
        </div>

        <div class="feature-modal-actions">
            <a id="lockModalWhatsappBtn" href="https://wa.me/93783788278?text=Hello%20Ahmad%20Najeem%20Nik,%20I%20would%20like%20to%20unlock%20this%20feature" target="_blank" class="btn-whatsapp-direct">
                <i class="fa-brands fa-whatsapp" style="font-size: 18px;"></i>
                <span>ارتباط در واتس‌اپ (+93783788278)</span>
            </a>
            <a href="tel:+93783788278" class="btn btn-secondary" style="font-size: 13px;">
                <i class="fa-solid fa-phone"></i> تماس تلفنی
            </a>
        </div>
    </div>
</div>

<script>
function showLockModal(key, titleEn, titleFa) {
    var modal = document.getElementById('featureLockModal');
    if (!modal) return;
    
    var tFa = document.getElementById('lockModalTitleFa');
    var tEn = document.getElementById('lockModalTitleEn');
    var waBtn = document.getElementById('lockModalWhatsappBtn');

    if (tFa && titleFa) tFa.textContent = titleFa + ' (قفل است)';
    if (tEn && titleEn) tEn.textContent = 'Feature Locked: ' + titleEn;
    
    if (waBtn) {
        var query = encodeURIComponent("Hello Ahmad Najeem Nik, I would like to request unlocking the feature: " + (titleEn || key) + " (" + (titleFa || '') + ")");
        waBtn.href = "https://wa.me/93783788278?text=" + query;
    }
    
    modal.style.display = 'flex';
}

function closeLockModal() {
    var modal = document.getElementById('featureLockModal');
    if (modal) modal.style.display = 'none';
}
</script>

<!-- Universal Screen Lock & Shopkeeper PIN System -->
<?php require_once __DIR__ . '/screen_lock_modal.php'; ?>

<!-- Main Application JS -->
<script src="<?= BASE_URL ?>assets/js/main.js?v=<?= APP_VERSION ?>"></script>
</body>
</html>

