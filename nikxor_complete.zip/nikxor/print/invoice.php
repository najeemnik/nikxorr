<?php
/**
 * NiKXor - Mobile Shop Management System
 * Dedicated A5 Invoice / بل فروشگاه ضیا
 * Size: A5 Portrait (148mm x 210mm)
 * URL: http://localhost/nikxor/print/invoice.php?id=X
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// Authentication
auth_require();

$saleId = (int)($_GET['id'] ?? 0);
$sale = null;
$items = [];

if ($saleId > 0) {
    $stmt = $pdo->prepare("SELECT s.*, u.fullname as staff_name 
                           FROM sales s 
                           LEFT JOIN users u ON s.created_by = u.id 
                           WHERE s.id = :id");
    $stmt->execute([':id' => $saleId]);
    $sale = $stmt->fetch();

    if ($sale) {
        $itemStmt = $pdo->prepare("SELECT * FROM sale_items WHERE sale_id = :sid ORDER BY id ASC");
        $itemStmt->execute([':sid' => $saleId]);
        $items = $itemStmt->fetchAll();
    }
}

if (!$sale) {
    die('<div style="font-family: sans-serif; text-align: center; margin-top: 50px; direction: rtl;">بل مورد نظر یافت نشد. <a href="../modules/sales.php">بازگشت</a></div>');
}

// Settings
$shopName         = get_setting('shop_name', DEFAULT_SHOP_NAME);
$shopLogo         = get_setting('shop_logo', '');
$phoneCentral     = get_setting('shop_phone_central', '0791510046 — اشکان');
$phoneSecondary   = get_setting('shop_phone_secondary', '0747230143 — احمد ضیا');
$phoneWhatsapp    = get_setting('shop_phone_whatsapp', '008619584867173');
$addressCentral   = get_setting('shop_address_central', 'کابل مقابل پل خشتی موبایل سنتر منزل چهارم دوکان A323');
$addressSecondary = get_setting('shop_address_secondary', 'موبایل سنتر منزل سوم دوکان A248');
$footerNote       = get_setting('invoice_footer_note', 'با تشکر از خریداری شما. اجناس بدون تکت و کارتن مسترد نمی گردد.');
$defaultFormat    = get_setting('invoice_format', 'a5');
$format           = $_GET['format'] ?? $defaultFormat;
$autoPrint        = (int)get_setting('auto_print_invoice', '0');

$saleDate = date('Y/m/d', strtotime($sale['created_at']));
$saleTime = date('H:i:s', strtotime($sale['created_at']));

// Handle Microsoft Word / Doc export
if ((isset($_GET['export']) && $_GET['export'] === 'doc') || $format === 'doc' && isset($_GET['download'])) {
    header("Content-Type: application/vnd.ms-word; charset=UTF-8");
    header("Content-Disposition: attachment; filename=invoice_" . preg_replace('/[^a-zA-Z0-9_-]/', '', $sale['invoice_no']) . ".doc");
    header("Cache-Control: private, max-age=0, must-revalidate");
    header("Pragma: public");
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">';
    echo '<head><meta charset="utf-8"><title>بل فروش ' . htmlspecialchars($sale['invoice_no']) . '</title>';
    echo '<style>
        body { font-family: Tahoma, Arial, sans-serif; direction: rtl; text-align: right; margin: 20px; font-size: 11pt; color: #1e293b; }
        .tbl { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .tbl th, .tbl td { border: 1px solid #333333; padding: 6px 8px; font-size: 10pt; text-align: center; }
        .tbl th { background-color: #f1f5f9; font-weight: bold; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #0f172a; padding-bottom: 10px; }
        .meta-table { width: 100%; margin-bottom: 15px; }
        .meta-table td { padding: 4px; font-size: 10pt; }
        .total-box { margin-top: 15px; border: 1px solid #333; padding: 10px; background: #f8fafc; }
    </style></head><body>';
    
    echo '<div class="header">';
    echo '<h1 style="margin: 0; font-size: 18pt;">' . htmlspecialchars($shopName) . '</h1>';
    echo '<p style="margin: 5px 0; font-size: 11pt;">بل رسمی فروش کالا و خدمات موبایل</p>';
    echo '<p style="margin: 2px 0; font-size: 9pt; color: #555;">شماره تماس: ' . htmlspecialchars($phoneCentral) . ' | واتساپ: ' . htmlspecialchars($phoneWhatsapp) . '</p>';
    echo '<p style="margin: 2px 0; font-size: 9pt; color: #555;">آدرس: ' . htmlspecialchars($addressCentral) . '</p>';
    echo '</div>';

    echo '<table class="meta-table">';
    echo '<tr>';
    echo '<td><strong>شماره بل:</strong> ' . htmlspecialchars($sale['invoice_no']) . '</td>';
    echo '<td><strong>تاریخ:</strong> ' . htmlspecialchars($saleDate) . ' ' . htmlspecialchars($saleTime) . '</td>';
    echo '</tr>';
    echo '<tr>';
    echo '<td><strong>نام مشتری:</strong> ' . htmlspecialchars($sale['customer_name']) . '</td>';
    echo '<td><strong>شماره تماس:</strong> ' . htmlspecialchars($sale['customer_phone'] ?: '-') . '</td>';
    echo '</tr>';
    echo '</table>';

    echo '<table class="tbl">';
    echo '<thead><tr>';
    echo '<th style="width: 30px;">#</th>';
    echo '<th>شرح جنس و مشخصات</th>';
    echo '<th style="width: 60px;">تعداد</th>';
    echo '<th style="width: 100px;">قیمت فی (افغانی)</th>';
    echo '<th style="width: 110px;">مجموع (افغانی)</th>';
    echo '</tr></thead><tbody>';
    
    $idx = 1;
    foreach ($items as $it) {
        echo '<tr>';
        echo '<td>' . $idx++ . '</td>';
        echo '<td style="text-align: right;">' . htmlspecialchars($it['product_name']) . '</td>';
        echo '<td>' . (int)$it['quantity'] . '</td>';
        echo '<td>' . number_format((float)($it['unit_sale_price'] ?? 0)) . '</td>';
        echo '<td>' . number_format((float)($it['total_price'] ?? 0)) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';

    echo '<div class="total-box">';
    echo '<p style="margin: 3px 0;"><strong>مبلغ کل بل:</strong> ' . number_format($sale['total_amount']) . ' افغانی</p>';
    echo '<p style="margin: 3px 0;"><strong>نوع پرداخت:</strong> ' . htmlspecialchars($sale['payment_type']) . '</p>';
    echo '<p style="margin: 3px 0;"><strong>مبلغ پرداخت شده:</strong> ' . number_format($sale['paid_amount']) . ' افغانی</p>';
    if ((float)$sale['remaining_amount'] > 0) {
        echo '<p style="margin: 3px 0; color: #b91c1c;"><strong>باقی مانده طلب:</strong> ' . number_format($sale['remaining_amount']) . ' افغانی</p>';
    }
    echo '</div>';

    if (!empty($footerNote)) {
        echo '<p style="margin-top: 15px; font-size: 9pt; color: #555; text-align: center;">' . htmlspecialchars($footerNote) . '</p>';
    }

    echo '</body></html>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بل فروش <?= sanitize($sale['invoice_no']) ?> - <?= sanitize($shopName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css?v=<?= APP_VERSION ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/print.css?v=<?= APP_VERSION ?>">
</head>
<body class="invoice-screen-wrapper">

<!-- Action Buttons Bar (Hidden on Print) -->
<div class="invoice-actions no-print" style="width: <?= ($format === 'thermal') ? '80mm' : '148mm' ?>;">
    <div style="display: flex; gap: 6px;">
        <a href="<?= BASE_URL ?>modules/invoices.php" class="btn btn-secondary btn-sm" title="مشاهده لیست تمام بل‌ها">
            <i class="fa-solid fa-list ml-1"></i> آرشیف بل‌ها
        </a>
        <a href="<?= BASE_URL ?>modules/sales.php" class="btn btn-secondary btn-sm" title="فروش کالا جدید">
            <i class="fa-solid fa-plus ml-1"></i> بل جدید
        </a>
    </div>
    <div style="display: flex; gap: 6px; flex-wrap: wrap;">
        <button type="button" onclick="window.print()" class="btn btn-primary btn-sm" title="چاپ یا ذخیره مستقیم به PDF">
            <i class="fa-solid fa-file-pdf ml-1"></i> پرینت و ذخیره PDF
        </button>
        <a href="?id=<?= $saleId ?>&export=doc" class="btn btn-secondary btn-sm" style="background: #1e3a8a; color: #ffffff;" title="دانلود سند آفیس قابل ویرایش">
            <i class="fa-solid fa-file-word ml-1"></i> دانلود Word
        </a>
        <a href="?id=<?= $saleId ?>&format=<?= ($format === 'thermal' ? 'a5' : 'thermal') ?>" class="btn btn-secondary btn-sm" title="تغییر ظاهر بل">
            <i class="fa-solid fa-receipt ml-1"></i> <?= ($format === 'thermal' ? 'بل A5' : 'فیش ۸۰mm') ?>
        </a>
    </div>
</div>

<!-- Invoice Sheet -->
<div class="invoice-container" style="<?= ($format === 'thermal') ? 'width: 80mm; min-height: auto; padding: 4mm;' : '' ?>">
    <div>
        <!-- TOP SECTION: Shop Logo & Name -->
        <div class="inv-header">
            <div class="inv-brand">
                <div class="inv-logo-box">
                    <?php if (!empty($shopLogo) && file_exists(__DIR__ . '/../uploads/' . $shopLogo)): ?>
                        <img src="<?= BASE_URL ?>uploads/<?= sanitize($shopLogo) ?>" alt="لوگو" style="max-height: 48px; max-width: 60px; object-fit: contain;">
                    <?php else: ?>
                        <i class="fa-solid fa-mobile-screen-button"></i>
                    <?php endif; ?>
                </div>
                <div class="inv-title">
                    <h1><?= sanitize($shopName) ?></h1>
                    <p>مرکز فروش انواع گوشی های هوشمند، لوازم جانبی و پرزه جات اصلی</p>
                </div>
            </div>
            <div class="inv-badge-box">
                <div class="bill-label">بل فروش رسمی</div>
            </div>
        </div>

        <!-- CONTACT INFORMATION & ADDRESSES -->
        <div class="inv-meta-grid">
            <div class="inv-meta-col">
                <p><strong><i class="fa-solid fa-phone ml-1"></i> شماره های تماس:</strong></p>
                <p><?= sanitize($phoneCentral) ?></p>
                <p><?= sanitize($phoneSecondary) ?></p>
                <p><i class="fa-brands fa-whatsapp ml-1"></i> واتساپ: <?= sanitize($phoneWhatsapp) ?></p>
            </div>
            <div class="inv-meta-col">
                <p><strong><i class="fa-solid fa-location-dot ml-1"></i> آدرس های فروشگاه:</strong></p>
                <p><strong>مرکزی:</strong> <?= sanitize($addressCentral) ?></p>
                <p><strong>دوکان دوم:</strong> <?= sanitize($addressSecondary) ?></p>
            </div>
        </div>

        <!-- INVOICE INFORMATION -->
        <div class="inv-details-strip">
            <div class="inv-detail-item">
                <span>شماره بل:</span>
                <strong><?= sanitize($sale['invoice_no']) ?></strong>
            </div>
            <div class="inv-detail-item">
                <span>تاریخ و ساعت:</span>
                <strong><?= to_persian_num($saleDate) ?> - <?= to_persian_num($saleTime) ?></strong>
            </div>
            <div class="inv-detail-item">
                <span>اسم مشتری:</span>
                <strong><?= sanitize($sale['customer_name']) ?></strong>
            </div>
            <div class="inv-detail-item">
                <span>شماره تماس:</span>
                <strong><?= sanitize($sale['customer_phone'] ?: '-') ?></strong>
            </div>
        </div>

        <!-- ITEMS TABLE -->
        <table class="inv-table">
            <thead>
                <tr>
                    <th style="width: 30px;">شماره</th>
                    <th>اسم جنس</th>
                    <th>مشخصات</th>
                    <th style="width: 45px;">تعداد</th>
                    <th style="width: 80px;">نرخ (افغانی)</th>
                    <th style="width: 85px;">مجموع (افغانی)</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $rNum = 1;
                foreach ($items as $item): 
                ?>
                    <tr>
                        <td><?= to_persian_num($rNum++) ?></td>
                        <td class="text-right"><strong><?= sanitize($item['product_name']) ?></strong></td>
                        <td class="text-right" style="font-size: 9.5px;"><?= sanitize($item['specifications'] ?: '-') ?></td>
                        <td><?= to_persian_num($item['quantity']) ?></td>
                        <td><?= format_money($item['unit_sale_price']) ?></td>
                        <td><strong><?= format_money($item['total_price']) ?></strong></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- BOTTOM: Grand Total, Payment Type Badge & Balance -->
        <div class="inv-summary-row">
            <div class="inv-payment-status">
                <div>
                    <span style="font-size: 10.5px; color: #475569;">نوع پرداخت: </span>
                    <?php if ($sale['payment_type'] === 'نقد'): ?>
                        <span class="payment-badge cash">نقدی (تصفیه کامل)</span>
                    <?php elseif ($sale['payment_type'] === 'قرض'): ?>
                        <span class="payment-badge debt">قرضه</span>
                    <?php else: ?>
                        <span class="payment-badge installment">قسط وار</span>
                    <?php endif; ?>
                </div>

                <?php if ((float)$sale['remaining_amount'] > 0): ?>
                    <div style="margin-top: 4px; font-size: 11px;">
                        <span>رسیدگی نقدی: <strong><?= format_money($sale['paid_amount']) ?></strong></span> | 
                        <span style="color: #b91c1c;">باقی مانده: <strong><?= format_money($sale['remaining_amount']) ?></strong></span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($sale['notes'])): ?>
                    <div style="font-size: 10px; color: #475569; margin-top: 4px;">
                        <strong>توضیحات:</strong> <?= sanitize($sale['notes']) ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="inv-grand-total">
                <div class="total-label">مجموع عمومی قابل پرداخت:</div>
                <div class="total-amount"><?= format_money($sale['total_amount']) ?></div>
            </div>
        </div>
    </div>

    <div>
        <!-- FOOTER NOTES & SIGNATURES -->
        <div class="inv-notes">
            <?= sanitize($footerNote) ?>
        </div>

        <div class="inv-signatures">
            <div>امضاء یا مهر فروشگاه ضیا: ____________</div>
            <div>امضاء یا شست مشتری: ____________</div>
        </div>

        <div class="inv-footer-msg">
            با تشکر از خریداری و اعتماد شما به <?= sanitize($shopName) ?>
        </div>
    </div>
</div>

<?php if ($autoPrint === 1): ?>
<script>
window.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        window.print();
    }, 500);
});
</script>
<?php endif; ?>

</body>
</html>
