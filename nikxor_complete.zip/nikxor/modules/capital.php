<?php
/**
 * NiKXor - Mobile Shop Management System
 * Shop Capital Management (سرمایه عمومی دکان)
 * URL: http://localhost/nikxor/modules/capital.php
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

auth_require();
$currentUser = auth_user();

$error = '';
$success = '';

// Handle Capital Entry
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_capital') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست!';
    } else {
        $amount = (float)normalize_digits($_POST['amount'] ?? '0');
        $transType = trim($_POST['transaction_type'] ?? 'سرمایه');
        $sourceDesc = trim($_POST['source_description'] ?? '');
        $transDate = !empty($_POST['transaction_date']) ? $_POST['transaction_date'] : date('Y-m-d');

        if ($amount <= 0) {
            $error = 'مبلغ وارد شده معتبر نیست.';
        } else {
            $stmt = $pdo->prepare("INSERT INTO capital (amount, transaction_type, source_description, transaction_date) 
                                   VALUES (:amt, :ttype, :sdesc, :tdate)");
            $stmt->execute([
                ':amt'   => $amount,
                ':ttype' => $transType,
                ':sdesc' => $sourceDesc,
                ':tdate' => $transDate
            ]);

            log_activity($currentUser['id'], 'تغییر سرمایه', "ثبت {$transType} به مبلغ " . format_money($amount));
            set_flash("عملیات حساب سرمایه با موفقیت ثبت گردید.", 'success');
            redirect(BASE_URL . 'modules/capital.php');
        }
    }
}

// Fetch all capital transactions
$transactions = $pdo->query("SELECT * FROM capital ORDER BY id DESC")->fetchAll();

// Total Capital Calculations
$totalInjected = 0;
$totalWithdrawn = 0;

foreach ($transactions as $tx) {
    if ($tx['transaction_type'] === 'برداشت') {
        $totalWithdrawn += (float)$tx['amount'];
    } else {
        $totalInjected += (float)$tx['amount'];
    }
}
$currentNetCapital = $totalInjected - $totalWithdrawn;

$pageTitle = 'گردش و حساب سرمایه دکان';
require_once __DIR__ . '/../includes/header.php';

$isLocked = is_feature_locked('capital_turnover');
?>

<?php if ($isLocked): ?>
<div class="card" style="margin-bottom: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h3 class="card-title" style="display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-vault ml-1"></i> مدیریت گردش سرمایه دکان
            <span class="badge-lock-tag"><i class="fa-solid fa-lock text-amber-500"></i> قفل می‌باشد</span>
        </h3>
        <a href="<?= BASE_URL ?>modules/partners.php" class="btn btn-secondary btn-sm">بازگشت به شرکا</a>
    </div>
</div>

<div class="locked-blur-wrapper">
    <div class="locked-blur-content" style="padding: 20px;">
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
            <div class="card" style="padding: 20px; border: 1px solid #cbd5e1;">
                <h4>گردش حساب سرمایه</h4>
                <p>مجموع سرمایه اولیه: ۵۰۰,۰۰۰ افغانی</p>
                <p>تزریق نقدینگی اخیر: ۱۰۰,۰۰۰ افغانی</p>
            </div>
            <div class="card" style="padding: 20px; border: 1px solid #cbd5e1;">
                <h4>تراکنش‌های بانکی و صندوق</h4>
                <p>تراکنش شماره ۱: افزایش سرمایه</p>
                <p>تراکنش شماره ۲: برداشت اضطراری</p>
            </div>
        </div>
    </div>
    <div class="locked-overlay-card">
        <h3><i class="fa-solid fa-lock mr-2"></i> این گزینه قفل می‌باشد</h3>
        <p style="font-size: 14px; margin-bottom: 8px;">جهت درخواست و فعال‌سازی این گزینه با احمد نجیم نیک تماس بگیرید</p>
        <p class="en-notice">This feature is currently locked. To request access and unlock this feature, please contact <strong>Ahmad Najeem Nik</strong>.</p>
        <a href="https://wa.me/93783788278?text=Hello%20Ahmad%20Najeem%20Nik,%20I%20would%20like%20to%20unlock%20Capital%20Turnover%20Management" target="_blank" class="btn-whatsapp-direct">
            <i class="fa-brands fa-whatsapp"></i> واتس‌اپ احمد نجیم نیک (+93783788278)
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; exit; endif; ?>


<div class="card" style="margin-bottom: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div>
            <h3 class="card-title" style="margin-bottom: 4px;">
                <i class="fa-solid fa-vault ml-1"></i> سرمایه در گردش فروشگاه ضیا
            </h3>
            <p style="font-size: 12.5px; color: #64748b;">
                موجودی خالص سرمایه: <strong style="color: #0f172a; font-size: 15px;"><?= format_money($currentNetCapital) ?></strong> | 
                مجموع تزریق شده: <?= format_money($totalInjected) ?> | 
                برداشت ها: <?= format_money($totalWithdrawn) ?>
            </p>
        </div>
        <div>
            <a href="<?= BASE_URL ?>modules/partners.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-users ml-1"></i> بازگشت به لست شرکا
            </a>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
    <!-- Add Capital Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa-solid fa-plus ml-1"></i> ثبت گردش سرمایه جدید
            </h3>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?= sanitize($error) ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_capital">

            <div class="form-group">
                <label class="form-label" for="transaction_type">نوع تراکنش:</label>
                <select id="transaction_type" name="transaction_type" class="form-control">
                    <option value="سرمایه">تزریق سرمایه جدید / افزایش سرمایه</option>
                    <option value="برداشت">برداشت از سرمایه</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label" for="amount">
                    مبلغ (افغانی): <span style="color: #ef4444;">*</span>
                </label>
                <input type="number" step="any" id="amount" name="amount" class="form-control numeric-input" required placeholder="مبلغ به افغانی">
            </div>

            <div class="form-group">
                <label class="form-label" for="source_description">توضیحات و منبع سرمایه:</label>
                <input type="text" id="source_description" name="source_description" class="form-control" placeholder="مثلاً: آورده نقدی احمد ضیا یا خرید اسناد تجارتی">
            </div>

            <div class="form-group">
                <label class="form-label" for="transaction_date">تاریخ تراکنش:</label>
                <input type="date" id="transaction_date" name="transaction_date" class="form-control" value="<?= date('Y-m-d') ?>">
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                <i class="fa-solid fa-check ml-1"></i> ثبت در گردش حساب
            </button>
        </form>
    </div>

    <!-- Capital History Table -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa-solid fa-clock-rotate-left ml-1"></i> تاریخچه تغییرات سرمایه دکان
            </h3>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>شماره</th>
                        <th>نوع</th>
                        <th>مبلغ (افغانی)</th>
                        <th>شرح و منبع</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #64748b; padding: 20px;">
                                تراکنشی ثبت نشده است.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php 
                        $tNum = 1;
                        foreach ($transactions as $tx): 
                        ?>
                            <tr>
                                <td><?= to_persian_num($tNum++) ?></td>
                                <td>
                                    <?php if ($tx['transaction_type'] === 'برداشت'): ?>
                                        <span class="badge badge-danger">برداشت</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">افزایش سرمایه</span>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?= format_money($tx['amount']) ?></strong></td>
                                <td><?= sanitize($tx['source_description'] ?: '-') ?></td>
                                <td><?= to_persian_num(date('Y/m/d', strtotime($tx['transaction_date']))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
