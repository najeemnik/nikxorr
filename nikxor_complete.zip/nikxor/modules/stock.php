<?php
/**
 * NiKXor - Mobile Shop Management System
 * Warehouse Stock Management Module
 * URL: http://localhost/nikxor/modules/stock.php
 */

$pageTitle = 'مدیریت گدام و لست اجناس';
require_once __DIR__ . '/../includes/header.php';

// Handle Item Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('خطای اعتبار سنجی امنیتی نشست!', 'danger');
        redirect(BASE_URL . 'modules/stock.php');
    }

    // 1. Single Item Delete
    if ($_POST['action'] === 'delete') {
        $deleteId = (int)($_POST['id'] ?? 0);
        if ($deleteId > 0) {
            try {
                $pStmt = $pdo->prepare("SELECT name FROM stock WHERE id = :id");
                $pStmt->execute([':id' => $deleteId]);
                $prodName = $pStmt->fetchColumn() ?: "شناسه {$deleteId}";

                // Safely unlink references in sale_items and expenses so historical records remain intact
                try {
                    $pdo->prepare("UPDATE sale_items SET stock_id = NULL WHERE stock_id = :id")->execute([':id' => $deleteId]);
                } catch (Exception $ex1) {}
                try {
                    $pdo->prepare("UPDATE expenses SET stock_id = NULL WHERE stock_id = :id")->execute([':id' => $deleteId]);
                } catch (Exception $ex2) {}

                $delStmt = $pdo->prepare("DELETE FROM stock WHERE id = :id");
                $delStmt->execute([':id' => $deleteId]);

                log_activity($currentUser['id'], 'حذف جنس از گدام', "حذف جنس «{$prodName}» با شناسه {$deleteId}");
                set_flash("جنس «{$prodName}» با موفقیت از گدام حذف گردید.", 'success');
            } catch (Exception $e) {
                set_flash('خطا در حذف جنس: ' . $e->getMessage(), 'danger');
            }
        }
        redirect(BASE_URL . 'modules/stock.php');
    }

    // 2. Bulk Delete Selected Items (سلکت کرده حذف کنم)
    if ($_POST['action'] === 'bulk_delete') {
        $selectedIds = $_POST['selected_ids'] ?? [];
        if (!is_array($selectedIds) || empty($selectedIds)) {
            set_flash('هیچ جنسی برای حذف انتخاب نشده است.', 'warning');
            redirect(BASE_URL . 'modules/stock.php');
        }

        $validIds = array_values(array_filter(array_map('intval', $selectedIds), fn($id) => $id > 0));
        if (empty($validIds)) {
            set_flash('شناسه‌های ارسالی معتبر نمی‌باشند.', 'danger');
            redirect(BASE_URL . 'modules/stock.php');
        }

        $placeholders = implode(',', array_fill(0, count($validIds), '?'));
        try {
            $pdo->beginTransaction();
            try {
                $upd1 = $pdo->prepare("UPDATE sale_items SET stock_id = NULL WHERE stock_id IN ($placeholders)");
                $upd1->execute($validIds);
            } catch (Exception $ex1) {}
            try {
                $upd2 = $pdo->prepare("UPDATE expenses SET stock_id = NULL WHERE stock_id IN ($placeholders)");
                $upd2->execute($validIds);
            } catch (Exception $ex2) {}

            $delStmt = $pdo->prepare("DELETE FROM stock WHERE id IN ($placeholders)");
            $delStmt->execute($validIds);
            $delCount = $delStmt->rowCount();
            $pdo->commit();

            log_activity($currentUser['id'], 'حذف گروهی اجناس', "حذف {$delCount} قلم جنس انتخاب شده از گدام");
            set_flash("تعداد " . to_persian_num($delCount) . " قلم جنس انتخاب شده با موفقیت از گدام حذف گردید.", 'success');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            set_flash('خطا در حذف گروهی اجناس: ' . $e->getMessage(), 'danger');
        }
        redirect(BASE_URL . 'modules/stock.php');
    }

    // 3. Delete All Items (پاکسازی کامل گدام - همه را یکجا حذف کنم)
    if ($_POST['action'] === 'delete_all') {
        $confirmPhrase = trim($_POST['confirm_phrase'] ?? '');
        if ($confirmPhrase !== 'حذف همه' && $confirmPhrase !== 'DELETE ALL' && $confirmPhrase !== '1') {
            set_flash('جهت پاکسازی کامل گدام، عبارت تأییدیه «حذف همه» الزامی است.', 'danger');
            redirect(BASE_URL . 'modules/stock.php');
        }

        try {
            $totalDeleted = (int)$pdo->query("SELECT COUNT(*) FROM stock")->fetchColumn();
            $pdo->beginTransaction();
            try {
                $pdo->exec("UPDATE sale_items SET stock_id = NULL");
            } catch (Exception $ex1) {}
            try {
                $pdo->exec("UPDATE expenses SET stock_id = NULL");
            } catch (Exception $ex2) {}

            $pdo->exec("DELETE FROM stock");
            try {
                $pdo->exec("DELETE FROM sqlite_sequence WHERE name='stock'");
            } catch (Exception $seqEx) {}
            $pdo->commit();

            log_activity($currentUser['id'], 'پاکسازی کامل گدام', "حذف یکجای تمام اجناس موجود در گدام ({$totalDeleted} قلم)");
            set_flash("تمام اجناس موجود در گدام (" . to_persian_num($totalDeleted) . " قلم جنس) با موفقیت به طور یکجا حذف شدند.", 'success');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            set_flash('خطا در پاکسازی گدام: ' . $e->getMessage(), 'danger');
        }
        redirect(BASE_URL . 'modules/stock.php');
    }
}

// Fetch categories for filter
$cats = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

// Query filtering
$search = trim($_GET['q'] ?? '');
$categoryFilter = (int)($_GET['category_id'] ?? 0);
$filterType = $_GET['filter'] ?? '';

$sql = "SELECT s.*, c.name AS category_name, p.name AS partner_name, 
               m.partner_name AS mudaraba_partner_name, m.project_title AS mudaraba_project_title 
        FROM stock s 
        LEFT JOIN categories c ON s.category_id = c.id 
        LEFT JOIN partners p ON s.partner_id = p.id 
        LEFT JOIN mudaraba_contracts m ON s.mudaraba_id = m.id 
        WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (s.name LIKE :q OR s.specifications LIKE :q OR s.supplier_name LIKE :q OR m.partner_name LIKE :q)";
    $params[':q'] = "%{$search}%";
}

if ($categoryFilter > 0) {
    $sql .= " AND s.category_id = :cat_id";
    $params[':cat_id'] = $categoryFilter;
}

if ($filterType === 'low') {
    $sql .= " AND s.quantity <= 3";
} elseif ($filterType === 'mudaraba') {
    $sql .= " AND s.mudaraba_id IS NOT NULL";
} elseif ($filterType === 'shop') {
    $sql .= " AND s.mudaraba_id IS NULL";
}

$sql .= " ORDER BY s.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

// Summary stats of current filtered list
$totalQty = 0;
$totalVal = 0;
foreach ($items as $it) {
    $totalQty += (int)$it['quantity'];
    $unitTotalCost = (float)$it['purchase_price'] + (float)$it['expenses'];
    $totalVal += ($unitTotalCost * (int)$it['quantity']);
}
?>

<div class="card" style="margin-bottom: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div>
            <h3 class="card-title" style="margin-bottom: 4px;">
                <i class="fa-solid fa-boxes-stacked ml-1"></i> لست اجناس و موجودی گدام
            </h3>
            <p style="font-size: 12.5px; color: #64748b;">
                مجموع: <strong><?= to_persian_num(count($items)) ?></strong> قلم جنس | تعداد کل: <strong><?= to_persian_num($totalQty) ?></strong> عدد | ارزش کل گدام: <strong><?= format_money($totalVal) ?></strong>
            </p>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <a href="<?= BASE_URL ?>modules/stock_add.php" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i> ثبت جنس جدید
            </a>
            <button type="button" onclick="openDeleteAllModal()" class="btn btn-danger" style="display: inline-flex; align-items: center; gap: 6px;" title="پاکسازی کامل تمام اجناس از گدام">
                <i class="fa-solid fa-trash-can"></i> پاکسازی کامل گدام (حذف همه)
            </button>
            <a href="<?= BASE_URL ?>modules/categories.php" class="btn btn-secondary">
                <i class="fa-solid fa-tags"></i> دسته بندی ها
            </a>
            <?php if (is_feature_locked('shelf_view')): ?>
                <button type="button" onclick="showLockModal('shelf_view', 'Shelf & Cupboard Visual View', 'نمای قفسه‌ها / الماری');" class="btn btn-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                    <i class="fa-solid fa-warehouse"></i> نمای قفسه ها (الماری)
                    <span class="badge-lock-tag" style="padding: 1px 6px; font-size: 10px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                </button>
            <?php else: ?>
                <a href="<?= BASE_URL ?>modules/warehouse.php" class="btn btn-secondary">
                    <i class="fa-solid fa-warehouse"></i> نمای قفسه ها (الماری)
                </a>
            <?php endif; ?>
        </div>

    </div>

    <!-- Search & Filter Form -->
    <form method="GET" action="" style="margin-top: 16px; display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 10px; align-items: end;">
        <div>
            <label class="form-label" style="font-size: 11.5px;">جستجوی جنس / مشخصات:</label>
            <input type="text" name="q" class="form-control" value="<?= sanitize($search) ?>" placeholder="مثلاً: آیفون، چارجر، S24...">
        </div>

        <div>
            <label class="form-label" style="font-size: 11.5px;">دسته بندی:</label>
            <select name="category_id" class="form-control">
                <option value="">همه دسته ها</option>
                <?php foreach ($cats as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= $categoryFilter === (int)$cat['id'] ? 'selected' : '' ?>>
                        <?= sanitize($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label class="form-label" style="font-size: 11.5px;">وضعیت موجودی و نوعیت سرمایه:</label>
            <select name="filter" class="form-control">
                <option value="">همه اجناس گدام</option>
                <option value="shop" <?= $filterType === 'shop' ? 'selected' : '' ?>>فقط اجناس عادی دکان</option>
                <option value="mudaraba" <?= $filterType === 'mudaraba' ? 'selected' : '' ?>>فقط اجناس حساب مضاربت (خارجی)</option>
                <option value="low" <?= $filterType === 'low' ? 'selected' : '' ?>>اجناس رو به اتمام (کمتر از ۳)</option>
            </select>
        </div>

        <div>
            <button type="submit" class="btn btn-secondary" style="height: 38px;">
                <i class="fa-solid fa-filter"></i> فیلتر
            </button>
            <?php if ($search !== '' || $categoryFilter > 0 || $filterType !== ''): ?>
                <a href="<?= BASE_URL ?>modules/stock.php" class="btn btn-sm btn-secondary" style="margin-right: 4px;" title="حذف فیلترها">
                    <i class="fa-solid fa-xmark"></i>
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- Bulk Selection Action Bar -->
<div id="bulkActionBar" class="card" style="display: none; background: #eff6ff; border: 1.5px solid #3b82f6; margin-bottom: 16px; padding: 12px 18px; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.12);">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <span style="font-weight: 800; color: #1e3a8a; font-size: 14px;">
                <i class="fa-solid fa-square-check text-blue-600 ml-1"></i> <span id="selectedCountText">۰</span> جنس انتخاب گردید
            </span>
            <button type="button" onclick="selectAllStockRows(true)" class="btn btn-sm btn-secondary" style="background: #ffffff;">
                <i class="fa-solid fa-list-check ml-1"></i> انتخاب تمام صفحه
            </button>
            <button type="button" onclick="selectAllStockRows(false)" class="btn btn-sm btn-secondary" style="background: #ffffff;">
                <i class="fa-solid fa-xmark ml-1"></i> لغو انتخاب‌ها
            </button>
        </div>
        <div>
            <button type="button" onclick="openBulkDeleteModal()" class="btn btn-danger btn-sm" style="display: inline-flex; align-items: center; gap: 6px; font-weight: 700;">
                <i class="fa-solid fa-trash-can"></i> حذف موارد انتخاب شده
            </button>
        </div>
    </div>
</div>

<!-- Hidden Form for Bulk Deletion -->
<form id="bulkDeleteForm" method="POST" action="" style="display: none;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="bulk_delete">
    <div id="bulkDeleteInputsContainer"></div>
</form>

<div class="card">
    <div class="table-responsive">
        <table class="table" id="stockTable">
            <thead>
                <tr>
                    <th style="width: 36px; text-align: center;">
                        <input type="checkbox" id="masterSelect" onchange="toggleMasterSelect(this)" title="انتخاب / عدم انتخاب همه" style="width: 17px; height: 17px; cursor: pointer;">
                    </th>
                    <th style="width: 35px;">#</th>
                    <th>اسم جنس</th>
                    <th>دسته بندی</th>
                    <th>مشخصات</th>
                    <th>موجودی</th>
                    <th>نرخ خرید</th>
                    <th>مصارف</th>
                    <th>تمام شد فی واحد</th>
                    <th>ارزش کل</th>
                    <th>
                        موقعیت
                        <?php if (is_feature_locked('warehouse_position')): ?>
                            <span class="badge-lock-tag" onclick="showLockModal('warehouse_position', 'Warehouse/Shelf Position', 'موقعیت در گدام/دکان');" style="cursor: pointer; font-size: 10px; padding: 1px 5px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                        <?php endif; ?>
                    </th>
                    <th>تاریخ و ساعت ثبت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="13" style="text-align: center; color: #64748b; padding: 24px;">
                            هیچ جنسی با مشخصات وارد شده یافت نشد.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php 
                    $rowNum = 1;
                    foreach ($items as $item): 
                        $unitCost = (float)$item['purchase_price'] + (float)$item['expenses'];
                        $totalStockVal = $unitCost * (int)$item['quantity'];
                    ?>
                        <tr id="stockRow_<?= $item['id'] ?>">
                            <td style="text-align: center;">
                                <input type="checkbox" name="stock_ids[]" value="<?= $item['id'] ?>" class="stock-item-chk" onchange="syncSelectionState()" style="width: 17px; height: 17px; cursor: pointer;">
                            </td>
                            <td><?= to_persian_num($rowNum++) ?></td>
                            <td>
                                <div style="font-weight: 700; color: #0f172a;"><?= sanitize($item['name']) ?></div>
                                <?php if (!empty($item['mudaraba_id']) && !empty($item['mudaraba_partner_name'])): ?>
                                    <div style="margin-top: 4px;">
                                        <a href="<?= BASE_URL ?>modules/mudaraba.php?contract_id=<?= (int)$item['mudaraba_id'] ?>" style="text-decoration: none;" title="مشاهده قرارداد مضاربت">
                                            <span class="badge" style="background: #ecfdf5; color: #047857; border: 1px solid #6ee7b7; font-size: 11px; padding: 2px 7px; display: inline-flex; align-items: center; gap: 4px; font-weight: 700;">
                                                <i class="fa-solid fa-handshake-angle"></i> حساب مضاربت با <?= sanitize($item['mudaraba_partner_name']) ?>
                                            </span>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($item['is_sample'])): ?>
                                    <span class="badge badge-secondary" style="font-size: 10px; margin-top: 3px;">نمونه</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-secondary">
                                    <?= sanitize($item['category_name'] ?? 'بدون دسته') ?>
                                </span>
                            </td>
                            <td style="font-size: 12px; color: #475569; max-width: 180px;">
                                <?= sanitize($item['specifications'] ?: '-') ?>
                            </td>
                            <td>
                                <?php if ((int)$item['quantity'] <= 0): ?>
                                    <span class="badge badge-danger">تمام شده (۰)</span>
                                <?php elseif ((int)$item['quantity'] <= 3): ?>
                                    <span class="badge badge-warning"><?= to_persian_num($item['quantity']) ?> عدد (کمبود)</span>
                                <?php else: ?>
                                    <span class="badge badge-success"><?= to_persian_num($item['quantity']) ?> عدد</span>
                                <?php endif; ?>
                            </td>
                            <td><?= format_money($item['purchase_price']) ?></td>
                            <td><?= format_money($item['expenses']) ?></td>
                            <td><strong><?= format_money($unitCost) ?></strong></td>
                            <td><strong><?= format_money($totalStockVal) ?></strong></td>
                            <td>
                                <?php if (is_feature_locked('warehouse_position')): ?>
                                    <span class="badge-lock-tag" onclick="showLockModal('warehouse_position', 'Warehouse/Shelf Position', 'موقعیت در گدام/دکان');" style="cursor: pointer; font-size: 11px;">
                                        <i class="fa-solid fa-lock text-amber-500"></i> قفل
                                    </span>
                                <?php else: ?>
                                    <span style="font-size: 11.5px; background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">
                                        <?= sanitize($item['warehouse_location'] ?? 'نامشخص') ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size: 11.5px; color: #64748b;">
                                <?= !empty($item['created_at']) ? to_persian_num(date('H:i - Y/m/d', strtotime($item['created_at']))) : '-' ?>
                            </td>
                            <td style="white-space: nowrap;">
                                <a href="<?= BASE_URL ?>modules/stock_edit.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-secondary" title="ویرایش">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <form method="POST" action="" style="display: inline-block;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" data-confirm="آیا از حذف جنس «<?= sanitize($item['name']) ?>» از گدام اطمینان کامل دارید؟" title="حذف دانه دانه">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal 1: Confirm Bulk Delete -->
<div id="bulkDeleteModal" class="feature-modal-backdrop" onclick="if(event.target === this) closeBulkDeleteModal();">
    <div class="feature-modal-box" style="max-width: 440px; text-align: right;">
        <button type="button" class="feature-modal-close" onclick="closeBulkDeleteModal();">&times;</button>
        <div style="text-align: center; margin-bottom: 12px;">
            <div style="width: 54px; height: 54px; background: #fee2e2; color: #ef4444; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 8px;">
                <i class="fa-solid fa-trash-can"></i>
            </div>
            <h3 style="font-size: 17px; font-weight: 800; color: #991b1b; margin: 0;">تأیید حذف گروهی اجناس انتخاب شده</h3>
        </div>
        <p style="font-size: 13.5px; color: #334155; line-height: 1.7; margin-bottom: 16px; text-align: center;">
            آیا از حذف کامل <strong id="modalBulkCountText" style="color: #ef4444;">۰</strong> قلم جنس انتخاب شده از گدام اطمینان قطعی دارید؟
            <br>
            <span style="font-size: 12px; color: #64748b;">(سوابق بل‌های صادر شده و گزارشات مالی قبلی به طور ایمن حفظ خواهند شد).</span>
        </p>
        <div style="display: flex; gap: 10px; justify-content: center;">
            <button type="button" onclick="executeBulkDeleteSubmit()" class="btn btn-danger" style="flex: 1; padding: 10px; font-weight: 700;">
                <i class="fa-solid fa-check ml-1"></i> بله، حذف شوند
            </button>
            <button type="button" onclick="closeBulkDeleteModal()" class="btn btn-secondary" style="flex: 1; padding: 10px;">
                لغو و بازگشت
            </button>
        </div>
    </div>
</div>

<!-- Modal 2: Confirm Delete All (پاکسازی کامل گدام) -->
<div id="deleteAllModal" class="feature-modal-backdrop" onclick="if(event.target === this) closeDeleteAllModal();">
    <div class="feature-modal-box" style="max-width: 480px; text-align: right;">
        <button type="button" class="feature-modal-close" onclick="closeDeleteAllModal();">&times;</button>
        <div style="text-align: center; margin-bottom: 12px;">
            <div style="width: 60px; height: 60px; background: #fee2e2; color: #dc2626; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 28px; margin-bottom: 8px;">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h3 style="font-size: 18px; font-weight: 800; color: #991b1b; margin: 0;">پاکسازی کامل گدام (حذف همه اجناس)</h3>
        </div>
        <div class="alert alert-danger" style="font-size: 13px; line-height: 1.7; margin-bottom: 14px;">
            <strong>هشدار بسیار مهم:</strong> با انجام این عملیات، <strong>تمام اجناس موجود در گدام به طور یکجا و کامل حذف خواهند شد</strong> و موجودی گدام صفر خواهد شد. این عملیات غیرقابل بازگشت است.
        </div>
        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_all">
            <div class="form-group" style="margin-bottom: 16px;">
                <label class="form-label" style="font-size: 13px; font-weight: 700;">
                    جهت تأیید، عبارت <span style="color: #dc2626;">«حذف همه»</span> را در کادر زیر تایپ نمایید:
                </label>
                <input type="text" id="confirmPhraseInput" name="confirm_phrase" class="form-control" placeholder="حذف همه" required oninput="checkDeleteAllPhrase(this.value)" autocomplete="off">
            </div>
            <div style="display: flex; gap: 10px; justify-content: center;">
                <button type="submit" id="confirmDeleteAllBtn" class="btn btn-danger" style="flex: 1; padding: 10px; font-weight: 700; opacity: 0.5; pointer-events: none;">
                    <i class="fa-solid fa-trash-can ml-1"></i> تأیید و پاکسازی کامل گدام
                </button>
                <button type="button" onclick="closeDeleteAllModal()" class="btn btn-secondary" style="flex: 1; padding: 10px;">
                    انصراف
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function getSelectedStockCheckboxes() {
    return Array.from(document.querySelectorAll('.stock-item-chk:checked'));
}

function syncSelectionState() {
    const chks = document.querySelectorAll('.stock-item-chk');
    const checked = document.querySelectorAll('.stock-item-chk:checked');
    const bar = document.getElementById('bulkActionBar');
    const countText = document.getElementById('selectedCountText');
    const master = document.getElementById('masterSelect');

    if (countText) {
        countText.textContent = checked.length;
    }

    if (checked.length > 0) {
        bar.style.display = 'block';
    } else {
        bar.style.display = 'none';
    }

    if (master) {
        master.checked = (chks.length > 0 && checked.length === chks.length);
        master.indeterminate = (checked.length > 0 && checked.length < chks.length);
    }
}

function toggleMasterSelect(master) {
    const chks = document.querySelectorAll('.stock-item-chk');
    chks.forEach(c => {
        c.checked = master.checked;
    });
    syncSelectionState();
}

function selectAllStockRows(select) {
    const chks = document.querySelectorAll('.stock-item-chk');
    chks.forEach(c => {
        c.checked = select;
    });
    syncSelectionState();
}

function openBulkDeleteModal() {
    const checked = getSelectedStockCheckboxes();
    if (checked.length === 0) {
        alert('لطفاً ابتدا حداقل یک جنس را انتخاب نمایید.');
        return;
    }
    document.getElementById('modalBulkCountText').textContent = checked.length;
    document.getElementById('bulkDeleteModal').style.display = 'flex';
}

function closeBulkDeleteModal() {
    document.getElementById('bulkDeleteModal').style.display = 'none';
}

function executeBulkDeleteSubmit() {
    const checked = getSelectedStockCheckboxes();
    if (checked.length === 0) return;

    const container = document.getElementById('bulkDeleteInputsContainer');
    container.innerHTML = '';
    checked.forEach(c => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_ids[]';
        input.value = c.value;
        container.appendChild(input);
    });

    document.getElementById('bulkDeleteForm').submit();
}

function openDeleteAllModal() {
    const modal = document.getElementById('deleteAllModal');
    const input = document.getElementById('confirmPhraseInput');
    const btn = document.getElementById('confirmDeleteAllBtn');
    if (input) input.value = '';
    if (btn) {
        btn.style.opacity = '0.5';
        btn.style.pointerEvents = 'none';
    }
    modal.style.display = 'flex';
    setTimeout(() => { if (input) input.focus(); }, 100);
}

function closeDeleteAllModal() {
    document.getElementById('deleteAllModal').style.display = 'none';
}

function checkDeleteAllPhrase(val) {
    const btn = document.getElementById('confirmDeleteAllBtn');
    const trimmed = val.trim();
    if (trimmed === 'حذف همه' || trimmed === 'DELETE ALL' || trimmed === '1') {
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
    } else {
        btn.style.opacity = '0.5';
        btn.style.pointerEvents = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
