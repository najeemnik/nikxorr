<?php
/**
 * NiKXor - Mobile Shop Management System
 * Losses and Damaged Goods Module (ضرر و خسارات اجناس)
 * URL: http://localhost/nikxor/modules/losses.php
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

auth_require();
$currentUser = auth_user();

$pageTitle = 'ضرر و خسارات اجناس';
$error = '';
$success = '';

// Handle Add Loss
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_loss') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست!';
    } else {
        $category    = trim($_POST['category'] ?? 'شکستگی و سوختگی قطعه');
        $amount      = (float)clean_number($_POST['amount'] ?? '0', true);
        $lossDate    = !empty($_POST['loss_date']) ? $_POST['loss_date'] : date('Y-m-d');
        $stockId     = !empty($_POST['stock_id']) ? (int)$_POST['stock_id'] : null;
        $lossQty     = !empty($_POST['loss_qty']) ? max(1, (int)$_POST['loss_qty']) : 1;
        $description = trim($_POST['description'] ?? '');
        $deductStock = !empty($_POST['deduct_stock']);
        $exactNow    = date('Y-m-d H:i:s');

        if ($amount <= 0) {
            $error = 'لطفاً مبلغ ضرر را به درستی وارد نمایید.';
        } else {
            // Insert into expenses table with expense_type = 'ضرر'
            $stmt = $pdo->prepare("INSERT INTO expenses (expense_type, category, amount, expense_date, description, stock_id, loss_qty, created_by, created_at) 
                                   VALUES ('ضرر', :cat, :amt, :ldate, :desc, :sid, :lqty, :uid, :cdate)");
            $stmt->execute([
                ':cat'   => $category,
                ':amt'   => $amount,
                ':ldate' => $lossDate,
                ':desc'  => $description,
                ':sid'   => $stockId,
                ':lqty'  => $lossQty,
                ':uid'   => $currentUser['id'],
                ':cdate' => $exactNow
            ]);

            // If selected from stock and checked to reduce warehouse inventory
            if ($deductStock && $stockId > 0) {
                $pdo->prepare("UPDATE stock SET quantity = MAX(0, quantity - :qty) WHERE id = :id")
                    ->execute([':qty' => $lossQty, ':id' => $stockId]);
            }

            log_activity($currentUser['id'], 'ثبت ضرر جنس', "ثبت ضرر به مبلغ " . format_money($amount) . " بابت «{$category}»");
            set_flash("ضرر و خسارت جنس با موفقیت ثبت شد.", 'success');
            redirect(BASE_URL . 'modules/losses.php');
        }
    }
}

// Handle Delete Loss
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_loss') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('خطای امنیتی نشست!', 'danger');
    } else {
        $delId = (int)($_POST['loss_id'] ?? 0);
        if ($delId > 0) {
            $stmt = $pdo->prepare("DELETE FROM expenses WHERE id = :id AND expense_type = 'ضرر'");
            $stmt->execute([':id' => $delId]);
            log_activity($currentUser['id'], 'حذف ضرر جنس', "حذف رکورد ضرر شناسه {$delId}");
            set_flash('رکورد ضرر با موفقیت حذف گردید.', 'success');
        }
    }
    redirect(BASE_URL . 'modules/losses.php');
}

// Filter parameters
$catFilter  = trim($_GET['category'] ?? '');
$dateFrom   = trim($_GET['date_from'] ?? '');
$dateTo     = trim($_GET['date_to'] ?? '');

$where = ["e.expense_type = 'ضرر'"];
$params = [];

if ($catFilter !== '') {
    $where[] = "e.category = :cat";
    $params[':cat'] = $catFilter;
}
if ($dateFrom !== '') {
    $where[] = "e.expense_date >= :dfrom";
    $params[':dfrom'] = $dateFrom;
}
if ($dateTo !== '') {
    $where[] = "e.expense_date <= :dto";
    $params[':dto'] = $dateTo;
}

$whereSql = "WHERE " . implode(" AND ", $where);

// Fetch Losses
$sql = "SELECT e.*, u.fullname as user_name, s.name as product_name 
        FROM expenses e 
        LEFT JOIN users u ON e.created_by = u.id 
        LEFT JOIN stock s ON e.stock_id = s.id 
        {$whereSql} 
        ORDER BY e.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$losses = $stmt->fetchAll();

// Metrics for Losses
$totalLossAll = (float)($pdo->query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE expense_type = 'ضرر'")->fetchColumn());

$curMonth = date('Y-m');
$stmtM = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE expense_type = 'ضرر' AND expense_date LIKE ?");
$stmtM->execute([$curMonth . '%']);
$totalLossMonth = (float)$stmtM->fetchColumn();

$curToday = date('Y-m-d');
$stmtT = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE expense_type = 'ضرر' AND expense_date = ?");
$stmtT->execute([$curToday]);
$totalLossToday = (float)$stmtT->fetchColumn();

// Fetch stock items for damage selection
$stockItems = $pdo->query("SELECT id, name, quantity, purchase_price FROM stock WHERE quantity > 0 ORDER BY name ASC LIMIT 100")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card" style="margin-bottom: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div>
            <h1 style="font-size: 20px; font-weight: 800; color: #991b1b; margin: 0; display: flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-triangle-exclamation text-danger"></i>
                مدیریت ضرر و خسارات اجناس (تفکیک شده از مصارف)
            </h1>
            <p style="font-size: 13px; color: #64748b; margin: 4px 0 0 0;">
                ثبت خسارات ناشی از شکستگی صفحه، سوختگی قطعات، افت قیمت یا مفقودی اجناس گدام
            </p>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="<?= BASE_URL ?>modules/expenses.php" class="btn btn-secondary" style="padding: 8px 14px;">
                <i class="fa-solid fa-wallet ml-1"></i> رفتن به مصارف دکان
            </a>
            <button onclick="window.print()" class="btn btn-secondary" style="padding: 8px 14px;">
                <i class="fa-solid fa-print ml-1"></i> چاپ جدول
            </button>
        </div>
    </div>
</div>

<!-- LOSS METRICS -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
    <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 12px; padding: 16px; text-align: center;">
        <div style="font-size: 12px; color: #991b1b; font-weight: 700; margin-bottom: 4px;">
            <i class="fa-solid fa-calendar-day ml-1"></i> ضرر ثبت شده امروز
        </div>
        <div style="font-size: 22px; font-weight: 800; color: #dc2626;"><?= format_money($totalLossToday) ?></div>
        <div style="font-size: 11px; color: #991b1b; margin-top: 4px;">تاریخ: <?= date('Y/m/d') ?></div>
    </div>

    <div style="background: #fff7ed; border: 1px solid #fed7aa; border-radius: 12px; padding: 16px; text-align: center;">
        <div style="font-size: 12px; color: #9a3412; font-weight: 700; margin-bottom: 4px;">
            <i class="fa-solid fa-calendar-days ml-1"></i> مجموع ضرر در ماه جاری
        </div>
        <div style="font-size: 22px; font-weight: 800; color: #ea580c;"><?= format_money($totalLossMonth) ?></div>
        <div style="font-size: 11px; color: #9a3412; margin-top: 4px;">خسارات این ماه</div>
    </div>

    <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 12px; padding: 16px; text-align: center;">
        <div style="font-size: 12px; color: #6b21a8; font-weight: 700; margin-bottom: 4px;">
            <i class="fa-solid fa-chart-pie ml-1"></i> مجموع کل ضرر و خسارات
        </div>
        <div style="font-size: 22px; font-weight: 800; color: #7e22ce;"><?= format_money($totalLossAll) ?></div>
        <div style="font-size: 11px; color: #6b21a8; margin-top: 4px;">از ابتدای کار دکان</div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
    <!-- Add Loss Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title" style="color: #991b1b;">
                <i class="fa-solid fa-circle-minus ml-1"></i> ثبت ضرر و خسارت جدید
            </h3>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?= sanitize($error) ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_loss">

            <div class="form-group">
                <label class="form-label" for="category">نوعیت و علت خسارت: <span style="color: #ef4444;">*</span></label>
                <select name="category" id="category" class="form-control" required>
                    <option value="شکستگی صفحه و تاچ">شکستگی صفحه و تاچ (LCD)</option>
                    <option value="سوختگی آی‌سی و بورد">سوختگی آی‌سی و بورد در حین کار</option>
                    <option value="خرابی و بادکردگی باطری">خرابی و بادکردگی باطری</option>
                    <option value="افت قیمت شدید جنس">افت قیمت شدید جنس در بازار</option>
                    <option value="سرقت یا مفقودی">سرقت یا مفقودی کالا</option>
                    <option value="سایر خسارات اجناس">سایر خسارات اجناس</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label" for="stock_id">انتخاب جنس از گدام (اختیاری):</label>
                <select name="stock_id" id="stock_id" class="form-control" onchange="autoFillPrice(this)">
                    <option value="">-- بدون جنس مشخص (خسارت عمومی) --</option>
                    <?php foreach ($stockItems as $si): ?>
                        <option value="<?= $si['id'] ?>" data-price="<?= (float)$si['purchase_price'] ?>">
                            <?= sanitize($si['name']) ?> (موجودی: <?= $si['quantity'] ?> دانه - خرید: <?= format_money($si['purchase_price'], false) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label class="form-label" for="amount">مبلغ کل ضرر (افغانی): <span style="color: #ef4444;">*</span></label>
                    <input type="number" step="any" min="1" id="amount" name="amount" class="form-control" required placeholder="مثلاً: ۱۵۰۰" style="font-weight: bold; color: #dc2626;">
                </div>
                <div class="form-group">
                    <label class="form-label" for="loss_qty">تعداد ضایع شده:</label>
                    <input type="number" min="1" id="loss_qty" name="loss_qty" class="form-control" value="1">
                </div>
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; cursor: pointer; color: #334155;">
                    <input type="checkbox" name="deduct_stock" value="1" checked>
                    <span>این تعداد از موجودی گدام کسر گردد</span>
                </label>
            </div>

            <div class="form-group">
                <label class="form-label" for="loss_date">تاریخ وقوع خسارت:</label>
                <input type="date" id="loss_date" name="loss_date" class="form-control" value="<?= date('Y-m-d') ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="description">شرح جزئیات و علت خسارت:</label>
                <textarea id="description" name="description" class="form-control" rows="2" placeholder="توضیح دهید چطور خسارت وارد شد (مثلاً: در هنگام تعویض گلس شکسته شد)..."></textarea>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; background: #dc2626; border-color: #dc2626; padding: 10px;">
                <i class="fa-solid fa-check ml-1"></i> ثبت نهایی ضرر جنس
            </button>
        </form>
    </div>

    <!-- Losses List Table -->
    <div class="card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <h3 class="card-title">
                <i class="fa-solid fa-list ml-1"></i> تاریخچه ضررها و خسارات ثبت شده
            </h3>
            <span class="badge" style="background: #fee2e2; color: #991b1b; font-size: 12px;">
                <?= count($losses) ?> مورد خسارت
            </span>
        </div>

        <!-- FILTER -->
        <form method="GET" action="" style="background: #f8fafc; padding: 10px; border-radius: 8px; margin-bottom: 14px; display: flex; gap: 8px; flex-wrap: wrap; align-items: flex-end;">
            <div style="flex: 1; min-width: 130px;">
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">علت ضرر:</label>
                <select name="category" class="form-control" style="font-size: 12px; padding: 6px;">
                    <option value="">همه علت‌ها</option>
                    <option value="شکستگی صفحه و تاچ" <?= $catFilter === 'شکستگی صفحه و تاچ' ? 'selected' : '' ?>>شکستگی صفحه</option>
                    <option value="سوختگی آی‌سی و بورد" <?= $catFilter === 'سوختگی آی‌سی و بورد' ? 'selected' : '' ?>>سوختگی بورد</option>
                    <option value="خرابی و بادکردگی باطری" <?= $catFilter === 'خرابی و بادکردگی باطری' ? 'selected' : '' ?>>خرابی باطری</option>
                    <option value="افت قیمت شدید جنس" <?= $catFilter === 'افت قیمت شدید جنس' ? 'selected' : '' ?>>افت قیمت</option>
                    <option value="سرقت یا مفقودی" <?= $catFilter === 'سرقت یا مفقودی' ? 'selected' : '' ?>>سرقت/مفقودی</option>
                </select>
            </div>
            <div style="flex: 1; min-width: 120px;">
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">از تاریخ:</label>
                <input type="date" name="date_from" class="form-control" style="font-size: 12px; padding: 6px;" value="<?= sanitize($dateFrom) ?>">
            </div>
            <div style="flex: 1; min-width: 120px;">
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">تا تاریخ:</label>
                <input type="date" name="date_to" class="form-control" style="font-size: 12px; padding: 6px;" value="<?= sanitize($dateTo) ?>">
            </div>
            <button type="submit" class="btn btn-sm btn-primary" style="height: 35px; padding: 0 12px;">فیلتر</button>
            <a href="<?= BASE_URL ?>modules/losses.php" class="btn btn-sm btn-secondary" style="height: 35px; padding: 0 10px;" title="حذف فیلتر"><i class="fa-solid fa-rotate-left"></i></a>
        </form>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 40px; text-align: center;">#</th>
                        <th>علت خسارت</th>
                        <th>جنس مربوطه</th>
                        <th style="text-align: center;">تعداد</th>
                        <th style="text-align: center;">مبلغ ضرر</th>
                        <th>تاریخ</th>
                        <th>توضیحات</th>
                        <th>ثبت‌کننده</th>
                        <th style="width: 60px; text-align: center;">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($losses)): ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 30px; color: #94a3b8;">
                                <i class="fa-solid fa-shield-halved" style="font-size: 28px; display: block; margin-bottom: 6px; color: #cbd5e1;"></i>
                                هیچ موردی برای ضرر و خسارت اجناس یافت نشد.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($losses as $idx => $ls): ?>
                            <tr>
                                <td style="text-align: center; font-weight: 700; color: #64748b;"><?= $idx + 1 ?></td>
                                <td>
                                    <span class="badge" style="background: #fee2e2; color: #991b1b; font-weight: 700;">
                                        <?= sanitize($ls['category']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?= sanitize($ls['product_name'] ?: 'جنس متفرقه / نامشخص') ?>
                                </td>
                                <td style="text-align: center; font-weight: 700;">
                                    <?= (int)($ls['loss_qty'] ?: 1) ?> دانه
                                </td>
                                <td style="text-align: center; font-weight: 800; color: #dc2626;">
                                    <?= format_money($ls['amount'], false) ?>
                                </td>
                                <td style="font-size: 12px; color: #64748b;">
                                    <?= sanitize($ls['expense_date']) ?>
                                </td>
                                <td style="font-size: 12px; color: #475569; max-width: 180px;">
                                    <?= sanitize($ls['description'] ?: '-') ?>
                                </td>
                                <td style="font-size: 12px; color: #64748b;">
                                    <?= sanitize($ls['user_name'] ?: 'سیستم') ?>
                                </td>
                                <td style="text-align: center;">
                                    <form method="POST" action="" style="display: inline;" onsubmit="return confirm('آیا از حذف این رکورد ضرر مطمئن هستید؟');">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete_loss">
                                        <input type="hidden" name="loss_id" value="<?= $ls['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" style="padding: 3px 8px;" title="حذف">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function autoFillPrice(sel) {
    var opt = sel.options[sel.selectedIndex];
    var price = opt.getAttribute('data-price');
    if (price && parseFloat(price) > 0) {
        var qty = parseInt(document.getElementById('loss_qty').value || 1);
        document.getElementById('amount').value = parseFloat(price) * qty;
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
