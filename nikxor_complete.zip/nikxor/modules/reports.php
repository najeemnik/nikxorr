<?php
/**
 * NiKXor - Mobile Shop Management System
 * Comprehensive Financial & Sales Reports (گزارشات مالی دکان)
 * URL: http://localhost/nikxor/modules/reports.php
 */

$pageTitle = 'گزارشات مالی و حسابداری دکان';
require_once __DIR__ . '/../includes/header.php';

// Date range filters
$quick = $_GET['quick'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

if ($quick === 'today') {
    $startDate = date('Y-m-d');
    $endDate = date('Y-m-d');
} elseif ($quick === 'this_week') {
    $startDate = date('Y-m-d', strtotime('-6 days'));
    $endDate = date('Y-m-d');
} elseif ($quick === 'this_month') {
    $startDate = date('Y-m-01');
    $endDate = date('Y-m-d');
} elseif (empty($startDate) && empty($endDate)) {
    // Default to this month
    $startDate = date('Y-m-01');
    $endDate = date('Y-m-d');
}

// Queries with date filters
$saleParams = [':s' => $startDate . ' 00:00:00', ':e' => $endDate . ' 23:59:59'];

// Sales stats in period
$salesStmt = $pdo->prepare("SELECT 
    COUNT(*) AS total_invoices,
    SUM(total_amount) AS total_sales_amount,
    SUM(paid_amount) AS total_paid_amount,
    SUM(remaining_amount) AS total_remaining_amount,
    SUM(profit) AS total_gross_profit
    FROM sales 
    WHERE created_at BETWEEN :s AND :e");
$salesStmt->execute($saleParams);
$salesStats = $salesStmt->fetch();

$totalInvoices        = (int)($salesStats['total_invoices'] ?? 0);
$totalSalesAmount     = (float)($salesStats['total_sales_amount'] ?? 0);
$totalPaidAmount      = (float)($salesStats['total_paid_amount'] ?? 0);
$totalRemainingAmount = (float)($salesStats['total_remaining_amount'] ?? 0);
$totalGrossProfit     = (float)($salesStats['total_gross_profit'] ?? 0);

// Expenses and losses in period
$expStmt = $pdo->prepare("SELECT 
    SUM(CASE WHEN expense_type = 'مصارف' THEN amount ELSE 0 END) AS total_expenses,
    SUM(CASE WHEN expense_type = 'ضرر' THEN amount ELSE 0 END) AS total_losses
    FROM expenses 
    WHERE expense_date BETWEEN :s AND :e");
$expStmt->execute([':s' => $startDate, ':e' => $endDate]);
$expStats = $expStmt->fetch();

$totalExpenses = (float)($expStats['total_expenses'] ?? 0);
$totalLosses   = (float)($expStats['total_losses'] ?? 0);
$totalDeductions = $totalExpenses + $totalLosses;

// Net Profit in period
$netProfit = $totalGrossProfit - $totalDeductions;

// Top sold items in period
$topItemsStmt = $pdo->prepare("SELECT 
    product_name,
    SUM(quantity) AS sold_qty,
    SUM(total_price) AS total_revenue,
    SUM(profit) AS total_item_profit
    FROM sale_items 
    WHERE created_at BETWEEN :s AND :e
    GROUP BY product_name 
    ORDER BY sold_qty DESC LIMIT 10");
$topItemsStmt->execute($saleParams);
$topItems = $topItemsStmt->fetchAll();

// Installments collected in period
$instStmt = $pdo->prepare("SELECT SUM(amount) AS total FROM installments WHERE payment_date BETWEEN :s AND :e");
$instStmt->execute([':s' => $startDate, ':e' => $endDate]);
$installmentsCollected = (float)($instStmt->fetch()['total'] ?? 0);
?>

<div class="card no-print" style="margin-bottom: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div>
            <h3 class="card-title" style="margin-bottom: 4px;">
                <i class="fa-solid fa-chart-line ml-1"></i> فیلتر گزارشات مالی و سود دکان
            </h3>
            <span style="font-size: 12px; color: #64748b;">
                بازه زمانی: از <?= to_persian_num($startDate) ?> تا <?= to_persian_num($endDate) ?>
            </span>
        </div>

        <div style="display: flex; gap: 6px;">
            <a href="<?= BASE_URL ?>modules/reports.php?quick=today" class="btn btn-sm <?= $quick === 'today' ? 'btn-primary' : 'btn-secondary' ?>">امروز</a>
            <a href="<?= BASE_URL ?>modules/reports.php?quick=this_week" class="btn btn-sm <?= $quick === 'this_week' ? 'btn-primary' : 'btn-secondary' ?>">۷ روز اخیر</a>
            <a href="<?= BASE_URL ?>modules/reports.php?quick=this_month" class="btn btn-sm <?= ($quick === 'this_month' || empty($quick)) ? 'btn-primary' : 'btn-secondary' ?>">این ماه</a>
            <button type="button" onclick="window.print()" class="btn btn-sm btn-primary">
                <i class="fa-solid fa-print ml-1"></i> چاپ گزارش
            </button>
        </div>
    </div>

    <!-- Custom date filter -->
    <form method="GET" action="" style="margin-top: 14px; display: flex; gap: 10px; align-items: end; flex-wrap: wrap;">
        <div>
            <label class="form-label" style="font-size: 11.5px;">از تاریخ:</label>
            <input type="date" name="start_date" class="form-control" value="<?= sanitize($startDate) ?>" required>
        </div>
        <div>
            <label class="form-label" style="font-size: 11.5px;">تا تاریخ:</label>
            <input type="date" name="end_date" class="form-control" value="<?= sanitize($endDate) ?>" required>
        </div>
        <div>
            <button type="submit" class="btn btn-secondary" style="height: 38px;">
                <i class="fa-solid fa-magnifying-glass"></i> اعمال تاریخ
            </button>
        </div>
    </form>
</div>

<!-- Report Summary Cards Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مجموع فروشات دوره</span>
            <div class="stat-icon icon-sales"><i class="fa-solid fa-cart-shopping"></i></div>
        </div>
        <div class="stat-value"><?= format_money($totalSalesAmount) ?></div>
        <div class="stat-desc"><?= to_persian_num($totalInvoices) ?> بل صادر شده</div>
    </div>

    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مفاد ناخالص فروشات</span>
            <div class="stat-icon icon-profit"><i class="fa-solid fa-arrow-trend-up"></i></div>
        </div>
        <div class="stat-value" style="color: #15803d;"><?= format_money($totalGrossProfit) ?></div>
        <div class="stat-desc">مفاد حاصل از تفاوت خرید و فروش</div>
    </div>

    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مصارف و ضررهای دکان</span>
            <div class="stat-icon icon-debt"><i class="fa-solid fa-receipt"></i></div>
        </div>
        <div class="stat-value" style="color: #b91c1c;"><?= format_money($totalDeductions) ?></div>
        <div class="stat-desc">مصارف: <?= format_money($totalExpenses) ?> | ضرر: <?= format_money($totalLosses) ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-title">مفاد خالص نهایی (Net Profit)</span>
            <div class="stat-icon icon-profit"><i class="fa-solid fa-sack-dollar"></i></div>
        </div>
        <div class="stat-value" style="color: <?= $netProfit >= 0 ? '#15803d' : '#b91c1c' ?>; font-size: 24px;">
            <?= format_money($netProfit) ?>
        </div>
        <div class="stat-desc">مفاد واقعی بعد از کسر تمام مصارف و خسارات</div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
    <!-- Cash Flow in Period -->
    <div class="card" style="position: relative;">
        <div class="card-header">
            <h3 class="card-title" style="display: flex; align-items: center; gap: 6px;">
                <i class="fa-solid fa-money-bill-transfer ml-1"></i> وضعیت نقدینگی و قرضه ها در این بازه
                <?php if (is_feature_locked('liquidity_report')): ?>
                    <span class="badge-lock-tag" onclick="showLockModal('liquidity_report', 'Cash Flow & Debts Period Report', 'وضعیت نقدینگی و قرضه‌ها در این دوره');" style="cursor: pointer;">
                        <i class="fa-solid fa-lock text-amber-500"></i> قفل
                    </span>
                <?php endif; ?>
            </h3>
        </div>
        <?php if (is_feature_locked('liquidity_report')): ?>
            <div class="locked-blur-wrapper" style="min-height: 220px;">
                <div class="locked-blur-content">
                    <table class="table">
                        <tbody>
                            <tr><td>مجموع نقدینگی دریافت شده از فروشات:</td><td><strong>120,000 افغانی</strong></td></tr>
                            <tr><td>اقساط و وصولی های دریافتی از قرضه ها:</td><td><strong>45,000 افغانی</strong></td></tr>
                            <tr><td>مجموع کل پول نقد وارد شده به صندوق:</td><td><strong>165,000 افغانی</strong></td></tr>
                            <tr><td>قرضه های پرداخت نشده مشتریان:</td><td><strong>30,000 افغانی</strong></td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="locked-overlay-card" style="padding: 16px;">
                    <h4 style="font-size: 13.5px; margin-bottom: 6px;"><i class="fa-solid fa-lock text-amber-500"></i> این گزینه قفل می‌باشد</h4>
                    <p style="font-size: 12px; margin-bottom: 6px;">جهت درخواست این گزینه با احمد نجیم نیک تماس بگیرید</p>
                    <p class="en-notice" style="font-size: 10.5px; margin-bottom: 8px;">This feature is currently locked. To request access, contact Ahmad Najeem Nik.</p>
                    <a href="https://wa.me/93783788278?text=Hello%20Ahmad%20Najeem%20Nik,%20I%20would%20like%20to%20unlock%20Cash%20Flow%20Report" target="_blank" class="btn-whatsapp-direct" style="padding: 6px 12px; font-size: 11px;">
                        <i class="fa-brands fa-whatsapp"></i> واتس‌اپ احمد نجیم نیک
                    </a>
                </div>
            </div>
        <?php else: ?>
            <table class="table">
                <tbody>
                    <tr>
                        <td>مجموع نقدینگی دریافت شده از فروشات:</td>
                        <td><strong style="color: #15803d;"><?= format_money($totalPaidAmount) ?></strong></td>
                    </tr>
                    <tr>
                        <td>اقساط و وصولی های دریافتی از قرضه ها:</td>
                        <td><strong style="color: #15803d;"><?= format_money($installmentsCollected) ?></strong></td>
                    </tr>
                    <tr>
                        <td>مجموع کل پول نقد وارد شده به صندوق:</td>
                        <td><strong style="color: #0f172a; font-size: 14px;"><?= format_money($totalPaidAmount + $installmentsCollected) ?></strong></td>
                    </tr>
                    <tr>
                        <td>قرضه های ثبت شده و پرداخت نشده مشتریان در این بازه:</td>
                        <td><strong style="color: #b91c1c;"><?= format_money($totalRemainingAmount) ?></strong></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Top Sold Products -->
    <div class="card" style="position: relative;">
        <div class="card-header">
            <h3 class="card-title" style="display: flex; align-items: center; gap: 6px;">
                <i class="fa-solid fa-fire ml-1"></i> پرفروش ترین اجناس در این دوره
                <?php if (is_feature_locked('top_selling_report')): ?>
                    <span class="badge-lock-tag" onclick="showLockModal('top_selling_report', 'Top Selling Products Report', 'پرفروش‌ترین اجناس در این دوره');" style="cursor: pointer;">
                        <i class="fa-solid fa-lock text-amber-500"></i> قفل
                    </span>
                <?php endif; ?>
            </h3>
        </div>
        <?php if (is_feature_locked('top_selling_report')): ?>
            <div class="locked-blur-wrapper" style="min-height: 220px;">
                <div class="locked-blur-content">
                    <table class="table">
                        <thead><tr><th>اسم جنس</th><th>تعداد</th><th>مجموع فروش</th><th>مفاد</th></tr></thead>
                        <tbody>
                            <tr><td>سامسونگ A55 5G</td><td>۱۲</td><td>240,000</td><td>18,000</td></tr>
                            <tr><td>چارجر اصل 25W سامسونگ</td><td>۳۵</td><td>17,500</td><td>5,250</td></tr>
                            <tr><td>آیفون 13 نرمال 128GB</td><td>۴</td><td>180,000</td><td>12,000</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="locked-overlay-card" style="padding: 16px;">
                    <h4 style="font-size: 13.5px; margin-bottom: 6px;"><i class="fa-solid fa-lock text-amber-500"></i> این گزینه قفل می‌باشد</h4>
                    <p style="font-size: 12px; margin-bottom: 6px;">جهت درخواست این گزینه با احمد نجیم نیک تماس بگیرید</p>
                    <p class="en-notice" style="font-size: 10.5px; margin-bottom: 8px;">This feature is currently locked. To request access and unlock this feature, please contact Ahmad Najeem Nik.</p>
                    <a href="https://wa.me/93783788278?text=Hello%20Ahmad%20Najeem%20Nik,%20I%20would%20like%20to%20unlock%20Top%20Selling%20Products%20Report" target="_blank" class="btn-whatsapp-direct" style="padding: 6px 12px; font-size: 11px;">
                        <i class="fa-brands fa-whatsapp"></i> واتس‌اپ احمد نجیم نیک
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>اسم جنس</th>
                            <th style="width: 70px; text-align: center;">تعداد</th>
                            <th style="width: 90px;">مجموع فروش</th>
                            <th style="width: 80px;">مفاد حاصله</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($topItems)): ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: #64748b; padding: 16px;">
                                    در این بازه زمانی فروشی ثبت نگردیده است.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($topItems as $top): ?>
                                <tr>
                                    <td><strong><?= sanitize($top['product_name']) ?></strong></td>
                                    <td style="text-align: center;"><span class="badge badge-secondary"><?= to_persian_num($top['sold_qty']) ?></span></td>
                                    <td><?= format_money($top['total_revenue']) ?></td>
                                    <td><strong style="color: #15803d;"><?= format_money($top['total_item_profit']) ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>


<?php require_once __DIR__ . '/../includes/footer.php'; ?>
