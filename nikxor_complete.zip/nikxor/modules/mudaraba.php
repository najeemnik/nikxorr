<?php
/**
 * NiKXor - Mobile Shop Management System
 * Mudaraba Partnership & Foreign Sourcing Module (حساب اختصاصی مضاربت و تجارت کالای خارجی)
 * URL: http://localhost/nikxor/modules/mudaraba.php
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

auth_require();
$currentUser = auth_user();

$pageTitle = 'حساب اختصاصی مضاربت و سرمایه‌گذاری خارجی';
$error = '';
$success = '';

// Fetch all categories for stock goods registration
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

// 1. Handle Add New Mudaraba Contract + Auto Save Goods into Warehouse (Stock)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_mudaraba') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست!';
    } else {
        $partnerName       = trim($_POST['partner_name'] ?? '');
        $phone             = trim($_POST['phone'] ?? '');
        $countrySource     = trim($_POST['country_source'] ?? 'دوبی (امارات)');
        $partnerRate       = (float)clean_number($_POST['partner_profit_rate'] ?? '50', true);
        $shopRate          = (float)clean_number($_POST['shop_profit_rate'] ?? '50', true);
        $startDate         = !empty($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-d');
        $settleDate        = !empty($_POST['settlement_date']) ? $_POST['settlement_date'] : null;
        $notes             = trim($_POST['notes'] ?? '');

        // Product / Warehouse fields
        $productName       = trim($_POST['product_name'] ?? '');
        $categoryId        = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $specifications    = trim($_POST['specifications'] ?? '');
        $quantity          = (int)clean_number($_POST['quantity'] ?? '0', false);
        $purchasePrice     = (float)clean_number($_POST['purchase_price'] ?? '0', true);
        $salePrice         = (float)clean_number($_POST['sale_price'] ?? '0', true);
        $expenses          = (float)clean_number($_POST['expenses'] ?? '0', true);
        $barcode           = trim($_POST['barcode'] ?? '');
        $warehouseLocation = trim($_POST['warehouse_location'] ?? '');

        // Calculate capital from goods: (purchasePrice + expenses) * quantity
        $unitCost          = $purchasePrice + $expenses;
        $calculatedCapital = $unitCost * $quantity;
        $manualCapital     = (float)clean_number($_POST['capital_amount'] ?? '0', true);
        $capitalAmount     = ($calculatedCapital > 0) ? $calculatedCapital : $manualCapital;

        $projectTitle = !empty($productName) 
            ? ($productName . ' (' . to_persian_num($quantity) . ' عدد)') 
            : trim($_POST['project_title'] ?? 'خرید کالای تجاری مضاربت');

        if (empty($partnerName)) {
            $error = 'لطفاً نام شریک سرمایه‌گذار مضاربت را وارد نمایید.';
        } elseif (empty($projectTitle)) {
            $error = 'لطفاً نام جنس یا عنوان پروژه مضاربت را مشخص نمایید.';
        } elseif ($capitalAmount <= 0) {
            $error = 'مقدار سرمایه مضاربت باید بیشتر از صفر باشد.';
        } else {
            try {
                $pdo->beginTransaction();

                // 1. Insert Mudaraba Contract
                $stmt = $pdo->prepare("INSERT INTO mudaraba_contracts 
                    (partner_name, phone, project_title, country_source, capital_amount, partner_profit_rate, shop_profit_rate, start_date, settlement_date, status, notes)
                    VALUES (:pname, :phone, :title, :country, :capital, :prate, :srate, :sdate, :edate, 'active', :notes)");
                $stmt->execute([
                    ':pname'   => $partnerName,
                    ':phone'   => $phone,
                    ':title'   => $projectTitle,
                    ':country' => $countrySource,
                    ':capital' => $capitalAmount,
                    ':prate'   => $partnerRate,
                    ':srate'   => $shopRate,
                    ':sdate'   => $startDate,
                    ':edate'   => $settleDate,
                    ':notes'   => $notes
                ]);

                $contractId = (int)$pdo->lastInsertId();

                // 2. Automatically save goods into warehouse (stock table) if product name and quantity provided
                if (!empty($productName) && $quantity > 0) {
                    $stockStmt = $pdo->prepare("INSERT INTO stock 
                        (name, category_id, specifications, quantity, purchase_price, sale_price, expenses, barcode, country_of_origin, supplier_name, warehouse_location, capital_amount, mudaraba_id, purchase_date, created_at)
                        VALUES (:name, :cat, :spec, :qty, :buy, :sale, :exp, :barcode, :orig, :supp, :loc, :cap, :mid, :pdate, :cdate)");
                    
                    $stockStmt->execute([
                        ':name'    => $productName,
                        ':cat'     => $categoryId,
                        ':spec'    => $specifications,
                        ':qty'     => $quantity,
                        ':buy'     => $purchasePrice,
                        ':sale'    => $salePrice,
                        ':exp'     => $expenses,
                        ':barcode' => $barcode,
                        ':orig'    => $countrySource,
                        ':supp'    => "خرید از پول مضاربت با " . $partnerName,
                        ':loc'     => $warehouseLocation,
                        ':cap'     => $capitalAmount,
                        ':mid'     => $contractId,
                        ':pdate'   => $startDate,
                        ':cdate'   => date('Y-m-d H:i:s')
                    ]);
                }

                $pdo->commit();
                log_activity($currentUser['id'], 'ثبت قرارداد و مال مضاربت', "ثبت قرارداد مضاربت «{$partnerName}» و ثبت جنس «{$productName}» به تعداد {$quantity} در گدام");
                set_flash("قرارداد مضاربت با «{$partnerName}» ثبت شد و جنس مربوطه مستقیماً با برچسب «حساب مضاربت با {$partnerName}» در گدام ذخیره گردید.", 'success');
                redirect(BASE_URL . 'modules/mudaraba.php');
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'خطا در ثبت قرارداد و گدام: ' . $e->getMessage();
            }
        }
    }
}

// 2. Handle Adding Extra Goods into Existing Mudaraba Contract
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_contract_item') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست!';
    } else {
        $contractId        = (int)($_POST['contract_id'] ?? 0);
        $productName       = trim($_POST['product_name'] ?? '');
        $categoryId        = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $specifications    = trim($_POST['specifications'] ?? '');
        $quantity          = (int)clean_number($_POST['quantity'] ?? '0', false);
        $purchasePrice     = (float)clean_number($_POST['purchase_price'] ?? '0', true);
        $salePrice         = (float)clean_number($_POST['sale_price'] ?? '0', true);
        $expenses          = (float)clean_number($_POST['expenses'] ?? '0', true);
        $barcode           = trim($_POST['barcode'] ?? '');
        $countrySource     = trim($_POST['country_source'] ?? '');
        $warehouseLocation = trim($_POST['warehouse_location'] ?? '');
        $purchaseDate      = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : date('Y-m-d');

        if ($contractId <= 0 || empty($productName) || $quantity <= 0) {
            $error = 'لطفاً نام جنس و تعداد معتبر را وارد نمایید.';
        } else {
            try {
                $pdo->beginTransaction();

                // Fetch contract partner name
                $cStmt = $pdo->prepare("SELECT partner_name, country_source FROM mudaraba_contracts WHERE id = :id");
                $cStmt->execute([':id' => $contractId]);
                $cRow = $cStmt->fetch();

                if (!$cRow) {
                    throw new Exception('قرارداد مضاربت یافت نشد.');
                }

                $partnerName = $cRow['partner_name'];
                if (empty($countrySource)) {
                    $countrySource = $cRow['country_source'];
                }

                $itemCapital = ($purchasePrice + $expenses) * $quantity;

                // Insert into stock
                $stockStmt = $pdo->prepare("INSERT INTO stock 
                    (name, category_id, specifications, quantity, purchase_price, sale_price, expenses, barcode, country_of_origin, supplier_name, warehouse_location, capital_amount, mudaraba_id, purchase_date, created_at)
                    VALUES (:name, :cat, :spec, :qty, :buy, :sale, :exp, :barcode, :orig, :supp, :loc, :cap, :mid, :pdate, :cdate)");
                
                $stockStmt->execute([
                    ':name'    => $productName,
                    ':cat'     => $categoryId,
                    ':spec'    => $specifications,
                    ':qty'     => $quantity,
                    ':buy'     => $purchasePrice,
                    ':sale'    => $salePrice,
                    ':exp'     => $expenses,
                    ':barcode' => $barcode,
                    ':orig'    => $countrySource,
                    ':supp'    => "خرید از پول مضاربت با " . $partnerName,
                    ':loc'     => $warehouseLocation,
                    ':cap'     => $itemCapital,
                    ':mid'     => $contractId,
                    ':pdate'   => $purchaseDate,
                    ':cdate'   => date('Y-m-d H:i:s')
                ]);

                // Update contract capital amount
                $updC = $pdo->prepare("UPDATE mudaraba_contracts SET capital_amount = capital_amount + :cap WHERE id = :id");
                $updC->execute([':cap' => $itemCapital, ':id' => $contractId]);

                $pdo->commit();
                log_activity($currentUser['id'], 'افزودن جنس به مضاربت', "افزودن جنس «{$productName}» به تعداد {$quantity} به قرارداد مضاربت #{$contractId}");
                set_flash("جنس «{$productName}» با موفقیت به قرارداد مضاربت افزوده و در گدام ذخیره شد.", 'success');
                redirect(BASE_URL . 'modules/mudaraba.php');
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'خطا در ثبت جنس: ' . $e->getMessage();
            }
        }
    }
}

// 3. Handle Record Sales / Profit Progress on Mudaraba Contract
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_progress') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست!';
    } else {
        $contractId   = (int)($_POST['contract_id'] ?? 0);
        $addSales     = (float)clean_number($_POST['add_sales'] ?? '0', true);
        $addProfit    = (float)clean_number($_POST['add_profit'] ?? '0', true);

        if ($contractId > 0 && ($addSales > 0 || $addProfit > 0)) {
            $stmt = $pdo->prepare("UPDATE mudaraba_contracts 
                SET total_sales_amount = total_sales_amount + :sales,
                    total_profit_amount = total_profit_amount + :profit
                WHERE id = :id");
            $stmt->execute([
                ':sales'  => $addSales,
                ':profit' => $addProfit,
                ':id'     => $contractId
            ]);

            log_activity($currentUser['id'], 'ثبت فروش مضاربت', "ثبت فروش {$addSales} و مفاد {$addProfit} برای قرارداد مضاربت #{$contractId}");
            set_flash("فروش و مفاد با موفقیت به حساب مضاربت افزوده شد.", 'success');
            redirect(BASE_URL . 'modules/mudaraba.php');
        } else {
            $error = 'مقادیر وارد شده نامعتبر است.';
        }
    }
}

// 4. Handle Payout / Settlement to Partner
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'payout_partner') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست!';
    } else {
        $contractId  = (int)($_POST['contract_id'] ?? 0);
        $payProfit   = (float)clean_number($_POST['payout_profit'] ?? '0', true);
        $returnCap   = (float)clean_number($_POST['return_capital'] ?? '0', true);
        $markSettled = !empty($_POST['mark_settled']) ? 'settled' : 'active';

        if ($contractId > 0 && ($payProfit > 0 || $returnCap > 0 || $markSettled === 'settled')) {
            $stmt = $pdo->prepare("UPDATE mudaraba_contracts 
                SET paid_profit_to_partner = paid_profit_to_partner + :profit,
                    returned_capital = returned_capital + :cap,
                    status = CASE WHEN :msettled = 'settled' THEN 'settled' ELSE status END
                WHERE id = :id");
            $stmt->execute([
                ':profit'   => $payProfit,
                ':cap'      => $returnCap,
                ':msettled' => $markSettled,
                ':id'       => $contractId
            ]);

            log_activity($currentUser['id'], 'پرداخت به شریک مضاربت', "پرداخت سود {$payProfit} و استرداد سرمایه {$returnCap} برای قرارداد مضاربت #{$contractId}");
            set_flash("پرداختی با موفقیت در حساب مضاربت ثبت گردید.", 'success');
            redirect(BASE_URL . 'modules/mudaraba.php');
        } else {
            $error = 'لطفاً مبلغ پرداختی را مشخص فرمایید.';
        }
    }
}

// 5. Handle Delete Contract
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_contract') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('خطای امنیتی نشست!', 'danger');
    } else {
        $delId = (int)($_POST['contract_id'] ?? 0);
        if ($delId > 0) {
            // Unlink any stock items
            $pdo->prepare("UPDATE stock SET mudaraba_id = NULL WHERE mudaraba_id = :id")->execute([':id' => $delId]);
            $pdo->prepare("DELETE FROM mudaraba_contracts WHERE id = :id")->execute([':id' => $delId]);
            log_activity($currentUser['id'], 'حذف قرارداد مضاربت', "حذف قرارداد مضاربت #{$delId}");
            set_flash("قرارداد مضاربت با موفقیت حذف گردید.", 'success');
            redirect(BASE_URL . 'modules/mudaraba.php');
        }
    }
}

// 6. Handle Edit Contract
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_contract') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('خطای امنیتی نشست!', 'danger');
    } else {
        $cId         = (int)($_POST['contract_id'] ?? 0);
        $partnerName = trim($_POST['partner_name'] ?? '');
        $phone       = trim($_POST['phone'] ?? '');
        $title       = trim($_POST['project_title'] ?? '');
        $country     = trim($_POST['country_source'] ?? '');
        $capital     = (float)clean_number($_POST['capital_amount'] ?? '0', true);
        $pRate       = (float)clean_number($_POST['partner_profit_rate'] ?? '50', true);
        $sRate       = (float)clean_number($_POST['shop_profit_rate'] ?? '50', true);
        $sDate       = !empty($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-d');
        $eDate       = !empty($_POST['settlement_date']) ? $_POST['settlement_date'] : null;
        $status      = trim($_POST['status'] ?? 'active');
        $notes       = trim($_POST['notes'] ?? '');

        if ($cId <= 0 || empty($partnerName) || empty($title)) {
            set_flash('لطفاً نام شریک و عنوان پروژه را مشخص نمایید.', 'danger');
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE mudaraba_contracts SET 
                    partner_name = :pname,
                    phone = :phone,
                    project_title = :title,
                    country_source = :country,
                    capital_amount = :capital,
                    partner_profit_rate = :prate,
                    shop_profit_rate = :srate,
                    start_date = :sdate,
                    settlement_date = :edate,
                    status = :status,
                    notes = :notes
                    WHERE id = :id");
                $stmt->execute([
                    ':pname'   => $partnerName,
                    ':phone'   => $phone,
                    ':title'   => $title,
                    ':country' => $country,
                    ':capital' => $capital,
                    ':prate'   => $pRate,
                    ':srate'   => $sRate,
                    ':sdate'   => $sDate,
                    ':edate'   => $eDate,
                    ':status'  => $status,
                    ':notes'   => $notes,
                    ':id'      => $cId
                ]);
                log_activity($currentUser['id'], 'ویرایش قرارداد مضاربت', "ویرایش قرارداد مضاربت #{$cId} با «{$partnerName}»");
                set_flash("قرارداد مضاربت با «{$partnerName}» با موفقیت ویرایش گردید.", 'success');
                redirect(BASE_URL . 'modules/mudaraba.php');
            } catch (Exception $e) {
                set_flash('خطا در ویرایش قرارداد مضاربت: ' . $e->getMessage(), 'danger');
            }
        }
    }
}

// 7. Handle Bulk Delete Contracts (سلکت و حذف گروهی قراردادها)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_delete_contracts') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('خطای امنیتی نشست!', 'danger');
        redirect(BASE_URL . 'modules/mudaraba.php');
    }

    $selectedIds = $_POST['selected_ids'] ?? [];
    if (!is_array($selectedIds) || empty($selectedIds)) {
        set_flash('هیچ قراردادی برای حذف انتخاب نشده است.', 'warning');
        redirect(BASE_URL . 'modules/mudaraba.php');
    }

    $validIds = array_values(array_filter(array_map('intval', $selectedIds), fn($id) => $id > 0));
    if (empty($validIds)) {
        set_flash('شناسه‌های ارسالی معتبر نمی‌باشند.', 'danger');
        redirect(BASE_URL . 'modules/mudaraba.php');
    }

    $placeholders = implode(',', array_fill(0, count($validIds), '?'));
    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE stock SET mudaraba_id = NULL WHERE mudaraba_id IN ($placeholders)")->execute($validIds);
        $delStmt = $pdo->prepare("DELETE FROM mudaraba_contracts WHERE id IN ($placeholders)");
        $delStmt->execute($validIds);
        $deletedCount = $delStmt->rowCount();
        $pdo->commit();

        log_activity($currentUser['id'], 'حذف گروهی قراردادهای مضاربت', "حذف {$deletedCount} قرارداد مضاربت انتخاب شده");
        set_flash("تعداد " . to_persian_num($deletedCount) . " قرارداد مضاربت با موفقیت حذف گردیدند.", 'success');
    } catch (Exception $e) {
        $pdo->rollBack();
        set_flash('خطا در حذف گروهی قراردادها: ' . $e->getMessage(), 'danger');
    }
    redirect(BASE_URL . 'modules/mudaraba.php');
}

// Fetch all Mudaraba contracts
$contracts = $pdo->query("SELECT * FROM mudaraba_contracts ORDER BY id DESC")->fetchAll();

// Calculate aggregate metrics strictly isolated for Mudaraba
$totalActiveCapital  = 0;
$totalMudarabaSales  = 0;
$totalMudarabaProfit = 0;
$totalPartnerShare   = 0;
$totalShopShare      = 0;
$totalPaidToPartners = 0;

foreach ($contracts as $c) {
    if ($c['status'] === 'active') {
        $totalActiveCapital += (float)$c['capital_amount'];
    }
    $totalMudarabaSales  += (float)$c['total_sales_amount'];
    $totalMudarabaProfit += (float)$c['total_profit_amount'];
    
    // Partner and shop shares
    $pShare = ((float)$c['total_profit_amount'] * (float)$c['partner_profit_rate']) / 100;
    $sShare = ((float)$c['total_profit_amount'] * (float)$c['shop_profit_rate']) / 100;
    
    $totalPartnerShare   += $pShare;
    $totalShopShare      += $sShare;
    $totalPaidToPartners += (float)$c['paid_profit_to_partner'];
}

$pendingPartnerPayout = max(0, $totalPartnerShare - $totalPaidToPartners);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card" style="margin-bottom: 24px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 20px;">
        <div>
            <h1 style="font-size: 20px; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-handshake-angle text-primary"></i>
                حساب اختصاصی مضاربت (خریداری و فروش کالای خارجی شرکتی)
            </h1>
            <p style="color: #64748b; font-size: 13px; margin: 4px 0 0 0;">
                ثبت سرمایه شریک، خریداری کالا از خارج، ثبت مستقیم در گدام با برچسب اختصاصی، و تقسیم مفاد شرعی
            </p>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button onclick="document.getElementById('addContractModal').style.display='flex'" class="btn btn-primary" style="padding: 8px 16px;">
                <i class="fa-solid fa-file-signature ml-1"></i> عقد قرارداد جدید و ثبت مال در گدام
            </button>
            <a href="<?= BASE_URL ?>modules/stock.php?filter=mudaraba" class="btn btn-secondary" style="padding: 8px 16px; background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0;">
                <i class="fa-solid fa-boxes-stacked ml-1"></i> مشاهده مال‌های مضاربت در گدام
            </a>
            <a href="<?= BASE_URL ?>modules/partners.php" class="btn btn-secondary" style="padding: 8px 16px;">
                <i class="fa-solid fa-users ml-1"></i> شرکاء عمومی دکان
            </a>
        </div>
    </div>

    <!-- MUDARABA EXCLUSIVE METRICS -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px; margin-bottom: 24px;">
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 16px; text-align: center;">
            <div style="font-size: 12px; color: #166534; font-weight: 700; margin-bottom: 4px;">
                <i class="fa-solid fa-vault ml-1"></i> مجموع سرمایه فعال مضاربت
            </div>
            <div style="font-size: 20px; font-weight: 800; color: #15803d;"><?= format_money($totalActiveCapital) ?></div>
            <div style="font-size: 11px; color: #166534; margin-top: 4px;">سرمایه اختصاصی شرکاء خارجی</div>
        </div>

        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 16px; text-align: center;">
            <div style="font-size: 12px; color: #1e40af; font-weight: 700; margin-bottom: 4px;">
                <i class="fa-solid fa-chart-line ml-1"></i> مجموع فروشات اجناس مضاربت
            </div>
            <div style="font-size: 20px; font-weight: 800; color: #1d4ed8;"><?= format_money($totalMudarabaSales) ?></div>
            <div style="font-size: 11px; color: #1e40af; margin-top: 4px;">ثبت خودکار هنگام فروش در بل</div>
        </div>

        <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 12px; padding: 16px; text-align: center;">
            <div style="font-size: 12px; color: #6b21a8; font-weight: 700; margin-bottom: 4px;">
                <i class="fa-solid fa-sack-dollar ml-1"></i> سهم مفاد شرکاء مضاربت
            </div>
            <div style="font-size: 20px; font-weight: 800; color: #7e22ce;"><?= format_money($totalPartnerShare) ?></div>
            <div style="font-size: 11px; color: #6b21a8; margin-top: 4px;">مانده تسویه نشده: <?= format_money($pendingPartnerPayout) ?></div>
        </div>

        <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 16px; text-align: center;">
            <div style="font-size: 12px; color: #92400e; font-weight: 700; margin-bottom: 4px;">
                <i class="fa-solid fa-building-columns ml-1"></i> سهم مفاد خالص دکان از مضاربت
            </div>
            <div style="font-size: 20px; font-weight: 800; color: #b45309;"><?= format_money($totalShopShare) ?></div>
            <div style="font-size: 11px; color: #92400e; margin-top: 4px;">درآمد حاصل از زحمت و فروشندگی</div>
        </div>
    </div>

    <!-- CONTRACTS TABLE -->
    <div style="margin-top: 20px;">
        <h2 style="font-size: 16px; font-weight: 700; color: #1e293b; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-list-check text-primary"></i> لیست قراردادهای مضاربت و اجناس ثبت‌شده در گدام
        </h2>

        <!-- BULK SELECTION ACTION BAR -->
        <div id="mudarabaBulkActionBar" class="card" style="display: none; background: #eff6ff; border: 1.5px solid #3b82f6; margin-bottom: 16px; padding: 12px 18px; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.12);">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                    <span style="font-weight: 800; color: #1e3a8a; font-size: 14px;">
                        <i class="fa-solid fa-square-check text-blue-600 ml-1"></i> <span id="mudarabaSelectedCountText">۰</span> قرارداد مضاربت انتخاب گردید
                    </span>
                    <button type="button" onclick="selectAllMudarabaRows(true)" class="btn btn-sm btn-secondary" style="background: #ffffff;">
                        <i class="fa-solid fa-list-check ml-1"></i> انتخاب همه
                    </button>
                    <button type="button" onclick="selectAllMudarabaRows(false)" class="btn btn-sm btn-secondary" style="background: #ffffff;">
                        <i class="fa-solid fa-xmark ml-1"></i> لغو انتخاب‌ها
                    </button>
                </div>
                <div>
                    <button type="button" onclick="confirmBulkDeleteMudaraba()" class="btn btn-danger btn-sm" style="display: inline-flex; align-items: center; gap: 6px; font-weight: 700;">
                        <i class="fa-solid fa-trash-can"></i> حذف قراردادهای انتخاب شده
                    </button>
                </div>
            </div>
        </div>

        <!-- Hidden Form for Bulk Deletion of Mudaraba Contracts -->
        <form id="mudarabaBulkDeleteForm" method="POST" action="" style="display: none;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="bulk_delete_contracts">
            <div id="mudarabaBulkDeleteInputsContainer"></div>
        </form>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 38px; text-align: center;">
                            <input type="checkbox" id="selectAllMudarabaHeader" onchange="toggleAllMudaraba(this)" title="انتخاب همه">
                        </th>
                        <th style="width: 40px; text-align: center;">#</th>
                        <th>شریک سرمایه‌گذار</th>
                        <th>شرح کالا و مشخصات پروژه</th>
                        <th>کشور مبدا</th>
                        <th style="text-align: center;">سرمایه اولیه</th>
                        <th style="text-align: center;">نسبت مفاد (شریک/دکان)</th>
                        <th style="text-align: center;">فروش تا اکنون</th>
                        <th style="text-align: center;">مفاد تحقق‌یافته</th>
                        <th style="text-align: center;">سهم شریک / پرداختی</th>
                        <th style="text-align: center;">وضعیت</th>
                        <th style="text-align: center; min-width: 220px;">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($contracts)): ?>
                        <tr>
                            <td colspan="12" style="text-align: center; padding: 36px 12px; color: #94a3b8;">
                                <i class="fa-solid fa-handshake-slash" style="font-size: 32px; display: block; margin-bottom: 8px; color: #cbd5e1;"></i>
                                تاکنون هیچ قرارداد مضاربتی ثبت نشده است. با کلیک بر روی «عقد قرارداد جدید و ثبت مال در گدام» اولین سرمایه‌گذاری را ثبت نمایید.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($contracts as $idx => $c): 
                            $pShare = ((float)$c['total_profit_amount'] * (float)$c['partner_profit_rate']) / 100;
                            $remPShare = max(0, $pShare - (float)$c['paid_profit_to_partner']);
                            
                            // Fetch stock items tied to this contract
                            $stkStmt = $pdo->prepare("SELECT s.*, c.name as category_name 
                                                      FROM stock s 
                                                      LEFT JOIN categories c ON s.category_id = c.id 
                                                      WHERE s.mudaraba_id = :mid 
                                                      ORDER BY s.id DESC");
                            $stkStmt->execute([':mid' => $c['id']]);
                            $cItems = $stkStmt->fetchAll();
                        ?>
                            <tr style="background: #ffffff;">
                                <td style="text-align: center;">
                                    <input type="checkbox" class="mudaraba-chk" value="<?= $c['id'] ?>" onchange="updateMudarabaBulkBar()">
                                </td>
                                <td style="text-align: center; font-weight: 700; color: #64748b;"><?= $idx + 1 ?></td>
                                <td>
                                    <div style="font-weight: 700; color: #0f172a; font-size: 14px;">
                                        <?= sanitize($c['partner_name']) ?>
                                    </div>
                                    <?php if (!empty($c['phone'])): ?>
                                        <div style="font-size: 11.5px; color: #64748b; direction: ltr; text-align: right;">
                                            <i class="fa-solid fa-phone" style="font-size: 10px;"></i> <?= sanitize($c['phone']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: #0284c7; font-size: 13.5px;">
                                        <?= sanitize($c['project_title']) ?>
                                    </div>
                                    <div style="font-size: 11px; color: #64748b; display: flex; align-items: center; gap: 8px; margin-top: 2px;">
                                        <span>تاریخ آغاز: <?= sanitize($c['start_date']) ?></span>
                                        <button type="button" onclick="toggleContractStock(<?= $c['id'] ?>)" class="btn btn-sm btn-secondary" style="padding: 1px 6px; font-size: 10.5px;">
                                            <i class="fa-solid fa-boxes-stacked ml-1"></i> اجناس در گدام (<?= to_persian_num(count($cItems)) ?>)
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge" style="background: #f1f5f9; color: #334155; font-size: 12px;">
                                        <i class="fa-solid fa-globe ml-1 text-primary"></i> <?= sanitize($c['country_source'] ?: 'خارجی') ?>
                                    </span>
                                </td>
                                <td style="text-align: center; font-weight: 800; color: #166534; font-size: 14px;">
                                    <?= format_money($c['capital_amount'], false) ?>
                                </td>
                                <td style="text-align: center;">
                                    <span style="font-weight: 700; color: #0f172a;">
                                        <?= (float)$c['partner_profit_rate'] ?>٪ / <?= (float)$c['shop_profit_rate'] ?>٪
                                    </span>
                                </td>
                                <td style="text-align: center; font-weight: 700; color: #0f172a; font-size: 13px;">
                                    <?= format_money($c['total_sales_amount'], false) ?>
                                </td>
                                <td style="text-align: center; font-weight: 800; color: #0284c7; font-size: 13.5px;">
                                    <?= format_money($c['total_profit_amount'], false) ?>
                                </td>
                                <td style="text-align: center;">
                                    <div style="font-weight: 800; color: #7e22ce; font-size: 13px;">
                                        <?= format_money($pShare, false) ?>
                                    </div>
                                    <div style="font-size: 11px; color: #15803d;">
                                        پرداخت شده: <?= format_money($c['paid_profit_to_partner'], false) ?>
                                    </div>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($c['status'] === 'active'): ?>
                                        <span class="badge badge-success">جاری و فعال</span>
                                    <?php elseif ($c['status'] === 'settled'): ?>
                                        <span class="badge badge-secondary">تسویه شده</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><?= sanitize($c['status']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: wrap;">
                                        <!-- Edit Contract Button -->
                                        <button type="button" class="btn btn-sm btn-secondary" style="background: #f1f5f9; color: #334155; padding: 4px 8px;"
                                                onclick='openEditContractModal(<?= json_encode([
                                                    'id' => (int)$c['id'],
                                                    'partner_name' => $c['partner_name'],
                                                    'phone' => $c['phone'] ?? '',
                                                    'project_title' => $c['project_title'],
                                                    'country_source' => $c['country_source'] ?? '',
                                                    'capital_amount' => (float)$c['capital_amount'],
                                                    'partner_profit_rate' => (float)$c['partner_profit_rate'],
                                                    'shop_profit_rate' => (float)$c['shop_profit_rate'],
                                                    'start_date' => $c['start_date'] ?? '',
                                                    'settlement_date' => $c['settlement_date'] ?? '',
                                                    'status' => $c['status'] ?? 'active',
                                                    'notes' => $c['notes'] ?? ''
                                                ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>);'
                                                title="ویرایش قرارداد">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>

                                        <!-- Add More Stock to this contract -->
                                        <button type="button" class="btn btn-sm btn-secondary" style="background: #e0f2fe; color: #0369a1; border-color: #bae6fd; padding: 4px 8px;" onclick="openAddStockModal(<?= $c['id'] ?>, '<?= sanitize(addslashes($c['partner_name'])) ?>', '<?= sanitize(addslashes($c['country_source'])) ?>')" title="افزودن جنس جدید به این قرارداد">
                                            <i class="fa-solid fa-plus"></i> مال
                                        </button>

                                        <!-- Update Sales Progress Button -->
                                        <button type="button" class="btn btn-sm btn-primary" style="padding: 4px 8px;" onclick="openProgressModal(<?= $c['id'] ?>, '<?= sanitize(addslashes($c['project_title'])) ?>')" title="ثبت دستی فروش و مفاد">
                                            <i class="fa-solid fa-chart-line"></i>
                                        </button>

                                        <!-- Payout to Partner Button -->
                                        <button type="button" class="btn btn-sm btn-secondary" style="background: #10b981; color: white; padding: 4px 8px;" onclick="openPayoutModal(<?= $c['id'] ?>, '<?= sanitize(addslashes($c['partner_name'])) ?>', <?= $remPShare ?>, <?= (float)$c['capital_amount'] - (float)$c['returned_capital'] ?>)" title="پرداخت و تسویه با شریک">
                                            <i class="fa-solid fa-money-bill-wave"></i>
                                        </button>

                                        <!-- Print Mudaraba Statement Button -->
                                        <a href="<?= BASE_URL ?>print/mudaraba.php?id=<?= $c['id'] ?>" target="_blank" class="btn btn-sm btn-secondary" style="padding: 4px 8px;" title="چاپ سند و قرارداد مضاربت">
                                            <i class="fa-solid fa-print"></i>
                                        </a>

                                        <!-- Delete Button -->
                                        <form method="POST" action="" style="display: inline; margin: 0;" onsubmit="return confirm('آیا از حذف این قرارداد مضاربت مطمئن هستید؟ (اجناس گدام از مضاربت جدا می‌شوند)');">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="delete_contract">
                                            <input type="hidden" name="contract_id" value="<?= $c['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" style="padding: 4px 8px;" title="حذف قرارداد">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>

                            <!-- Expandable Stock Items Table for this Contract -->
                            <tr id="contract_stock_row_<?= $c['id'] ?>" style="display: none; background: #f8fafc;">
                                <td colspan="12" style="padding: 12px 18px;">
                                    <div style="background: #ffffff; border: 1.5px solid #cbd5e1; border-radius: 8px; padding: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.03);">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                            <h4 style="margin: 0; font-size: 13.5px; font-weight: 800; color: #047857; display: flex; align-items: center; gap: 6px;">
                                                <i class="fa-solid fa-boxes-stacked"></i>
                                                اجناس موجود در گدام مربوط به حساب مضاربت با «<?= sanitize($c['partner_name']) ?>»:
                                            </h4>
                                            <button type="button" onclick="openAddStockModal(<?= $c['id'] ?>, '<?= sanitize(addslashes($c['partner_name'])) ?>', '<?= sanitize(addslashes($c['country_source'])) ?>')" class="btn btn-sm btn-primary" style="font-size: 11.5px; padding: 3px 10px;">
                                                <i class="fa-solid fa-plus ml-1"></i> ثبت قلم جنس جدید برای این قرارداد
                                            </button>
                                        </div>

                                        <?php if (empty($cItems)): ?>
                                            <div style="padding: 12px; text-align: center; color: #94a3b8; font-size: 12.5px;">
                                                هنوز جنسی برای این قرارداد در گدام ثبت نشده است. می‌توانید با دکمه بالا جنس جدید ثبت نمایید.
                                            </div>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table" style="margin: 0; font-size: 12.5px;">
                                                    <thead>
                                                        <tr style="background: #f1f5f9;">
                                                            <th>#</th>
                                                            <th>اسم جنس</th>
                                                            <th>دسته‌بندی</th>
                                                            <th>مشخصات فنی (حافظه، رنگ، کارتن...)</th>
                                                            <th style="text-align: center;">موجودی فعلی در گدام</th>
                                                            <th style="text-align: center;">نرخ خرید</th>
                                                            <th style="text-align: center;">نرخ پیشنهادی فروش</th>
                                                            <th style="text-align: center;">ارزش موجودی گدام</th>
                                                            <th style="text-align: center;">موقعیت در دکان</th>
                                                            <th style="text-align: center;">برچسب در گدام</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php 
                                                        $subIdx = 1;
                                                        foreach ($cItems as $sItem): 
                                                            $totalItemVal = ((float)$sItem['purchase_price'] + (float)$sItem['expenses']) * (int)$sItem['quantity'];
                                                        ?>
                                                            <tr>
                                                                <td><?= $subIdx++ ?></td>
                                                                <td style="font-weight: 700; color: #0f172a;">
                                                                    <?= sanitize($sItem['name']) ?>
                                                                </td>
                                                                <td>
                                                                    <span class="badge badge-secondary"><?= sanitize($sItem['category_name'] ?? 'بدون دسته') ?></span>
                                                                </td>
                                                                <td style="color: #475569; max-width: 200px;">
                                                                    <?= sanitize($sItem['specifications'] ?: '-') ?>
                                                                </td>
                                                                <td style="text-align: center; font-weight: 800;">
                                                                    <?php if ((int)$sItem['quantity'] <= 0): ?>
                                                                        <span class="badge badge-danger">تمام شده (۰)</span>
                                                                    <?php else: ?>
                                                                        <span style="color: #047857; font-size: 13.5px;"><?= to_persian_num($sItem['quantity']) ?> عدد</span>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td style="text-align: center;"><?= format_money($sItem['purchase_price'], false) ?></td>
                                                                <td style="text-align: center; color: #0284c7; font-weight: 700;"><?= format_money($sItem['sale_price'], false) ?></td>
                                                                <td style="text-align: center; font-weight: 800; color: #166534;"><?= format_money($totalItemVal, false) ?></td>
                                                                <td style="text-align: center;"><?= sanitize($sItem['warehouse_location'] ?: '-') ?></td>
                                                                <td style="text-align: center;">
                                                                    <span class="badge" style="background: #ecfdf5; color: #047857; border: 1px solid #6ee7b7; font-size: 11px;">
                                                                        حساب مضاربت با <?= sanitize($c['partner_name']) ?>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODAL 1: ADD MUDARABA CONTRACT & AUTO SAVE GOODS TO STOCK -->
<div id="addContractModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 16px;">
    <div style="background: #ffffff; border-radius: 16px; max-width: 680px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); padding: 24px; position: relative;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="font-size: 16px; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-handshake text-primary"></i> عقد قرارداد جدید مضاربت و ثبت مال در گدام
            </h3>
            <button type="button" onclick="document.getElementById('addContractModal').style.display='none'" style="background: none; border: none; font-size: 18px; color: #64748b; cursor: pointer;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_mudaraba">

            <!-- Section 1: Partner Info -->
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 14px;">
                <div style="font-weight: 800; font-size: 13px; color: #1e293b; margin-bottom: 8px;">
                    <i class="fa-solid fa-user-tie text-primary ml-1"></i> ۱. مشخصات شریک سرمایه‌گذار (رب‌المال):
                </div>
                <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 12px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نام شریک: <span style="color: #ef4444;">*</span></label>
                        <input type="text" name="partner_name" class="form-control" required placeholder="مثلاً: حاجی نصرت‌الله">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">شماره تماس:</label>
                        <input type="text" name="phone" class="form-control" placeholder="۰۷۸۸۱۲۳۴۵۶">
                    </div>
                </div>
            </div>

            <!-- Section 2: Goods & Warehouse Specifications -->
            <div style="background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 8px; padding: 14px; margin-bottom: 14px;">
                <div style="font-weight: 800; font-size: 13px; color: #065f46; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between;">
                    <span><i class="fa-solid fa-boxes-stacked ml-1"></i> ۲. مشخصات مال خریداری‌شده (ثبت مستقیم در گدام):</span>
                    <span class="badge" style="background: #dcfce7; color: #166534; font-size: 11px;">ذخیره مستقیم در گدام دکان</span>
                </div>

                <div style="display: grid; grid-template-columns: 1.4fr 1fr; gap: 12px; margin-bottom: 12px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نام جنس و مدل: <span style="color: #ef4444;">*</span></label>
                        <input type="text" id="m_product_name" name="product_name" class="form-control" required placeholder="مثلاً: Samsung Galaxy A55 5G یا iPhone 13 Pro">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">دسته‌بندی در گدام:</label>
                        <select name="category_id" class="form-control">
                            <option value="">-- بدون دسته‌بندی --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= sanitize($cat['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group" style="margin-bottom: 12px;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مشخصات جنس (حافظه، رم، رنگ، سلامت بتری، کارتن و...):</label>
                    <textarea name="specifications" class="form-control" rows="2" placeholder="مثلاً: 256GB / 8GB RAM - رنگ سرمه‌ای - با کارتن و لوازم اورجینال"></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">تعداد خریداری شده: <span style="color: #ef4444;">*</span></label>
                        <input type="number" id="m_quantity" name="quantity" class="form-control" min="1" value="1" required oninput="recalcMudarabaCapital()">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نرخ خرید فی دانه (افغانی): <span style="color: #ef4444;">*</span></label>
                        <input type="number" step="any" id="m_purchase_price" name="purchase_price" class="form-control" min="0" required placeholder="قیمت خرید" oninput="recalcMudarabaCapital()">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نرخ فروش فی دانه (افغانی):</label>
                        <input type="number" step="any" name="sale_price" class="form-control" min="0" placeholder="قیمت فروش">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مصارف سرجمع فی دانه:</label>
                        <input type="number" step="any" id="m_expenses" name="expenses" class="form-control" min="0" value="0" placeholder="کرایه، گمرک" oninput="recalcMudarabaCapital()">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">کشور مبدأ خریداری:</label>
                        <select name="country_source" class="form-control">
                            <option value="دوبی (امارات)">دوبی (امارات)</option>
                            <option value="چین">چین</option>
                            <option value="ترکیه">ترکیه</option>
                            <option value="ایران">ایران</option>
                            <option value="پاکستان">پاکستان</option>
                            <option value="جاپان">جاپان</option>
                            <option value="سایر">سایر کشورها</option>
                        </select>
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">موقعیت در گدام/دکان:</label>
                        <input type="text" name="warehouse_location" class="form-control" placeholder="قفسه A، الماری ۱...">
                    </div>
                </div>

                <div class="form-group" style="margin-top: 10px; margin-bottom: 0;">
                    <label class="form-label" style="font-size: 12px;">بارکد یا سریال / IMEI جنس (اختیاری):</label>
                    <input type="text" name="barcode" class="form-control" placeholder="بارکد یا IMEI">
                </div>
            </div>

            <!-- Section 3: Financials & Shariah Profit Split -->
            <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 8px; padding: 14px; margin-bottom: 14px;">
                <div style="font-weight: 800; font-size: 13px; color: #581c87; margin-bottom: 8px;">
                    <i class="fa-solid fa-scale-balanced text-primary ml-1"></i> ۳. سرمایه مضاربت و تقسیم مفاد شرعی:
                </div>

                <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 12px; margin-bottom: 12px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مجموع سرمایه نقدی شریک (افغانی): <span style="color: #ef4444;">*</span></label>
                        <input type="number" step="any" id="m_capital_amount" name="capital_amount" class="form-control" required style="font-weight: 800; color: #166534; font-size: 14px;">
                        <small style="color: #64748b; font-size: 11px;">* خودبخود از ضرب تعداد در تمام‌شد جنس محاسبه می‌گردد.</small>
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" style="font-weight: 700; font-size: 12.5px;">تاریخ شروع مضاربت:</label>
                        <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>
                </div>

                <div style="background: #ffffff; border: 1px solid #d8b4fe; border-radius: 8px; padding: 10px;">
                    <span style="font-size: 12px; font-weight: 700; color: #6b21a8; display: block; margin-bottom: 6px;">
                        نسبت توافقی تقسیم سود حاصل از فروش کالا:
                    </span>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div>
                            <span style="font-size: 11.5px; color: #64748b;">سهم سود شریک (رب‌المال):</span>
                            <div style="display: flex; align-items: center; gap: 6px; margin-top: 4px;">
                                <input type="number" id="mudaraba_p_rate" name="partner_profit_rate" class="form-control" value="50" min="0" max="100" style="text-align: center; font-weight: bold;" oninput="document.getElementById('mudaraba_s_rate').value = Math.max(0, 100 - parseFloat(this.value || 0));">
                                <span style="font-weight: bold;">٪</span>
                            </div>
                        </div>
                        <div>
                            <span style="font-size: 11.5px; color: #64748b;">سهم سود دکان (عامل / مضارب):</span>
                            <div style="display: flex; align-items: center; gap: 6px; margin-top: 4px;">
                                <input type="number" id="mudaraba_s_rate" name="shop_profit_rate" class="form-control" value="50" min="0" max="100" style="text-align: center; font-weight: bold;">
                                <span style="font-weight: bold;">٪</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">توضیحات و شرایط ویژه قرارداد:</label>
                <textarea name="notes" class="form-control" rows="2" placeholder="توضیحات اختیاری در مورد توافقات، نرخ ارز، نحوه تصفیه..."></textarea>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 8px;">
                <button type="button" onclick="document.getElementById('addContractModal').style.display='none'" class="btn btn-secondary">
                    انصراف
                </button>
                <button type="submit" class="btn btn-primary" style="padding: 10px 20px;">
                    <i class="fa-solid fa-check ml-1"></i> ثبت قرارداد و ذخیره جنس در گدام
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 2: ADD EXTRA GOODS TO EXISTING CONTRACT -->
<div id="addStockModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 16px;">
    <div style="background: #ffffff; border-radius: 16px; max-width: 600px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); padding: 24px; position: relative;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="font-size: 15px; font-weight: 800; color: #0f172a; margin: 0;">
                <i class="fa-solid fa-plus text-primary ml-1"></i> ثبت جنس جدید برای قرارداد مضاربت: <span id="add_stock_partner_name" style="color: #0284c7;"></span>
            </h3>
            <button type="button" onclick="document.getElementById('addStockModal').style.display='none'" style="background: none; border: none; font-size: 18px; color: #64748b; cursor: pointer;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_contract_item">
            <input type="hidden" id="add_stock_contract_id" name="contract_id" value="">

            <div style="display: grid; grid-template-columns: 1.4fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نام جنس و مدل: <span style="color: #ef4444;">*</span></label>
                    <input type="text" name="product_name" class="form-control" required placeholder="مثلاً: شارژر فست، باتری، قاب...">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">دسته‌بندی:</label>
                    <select name="category_id" class="form-control">
                        <option value="">-- بدون دسته‌بندی --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= sanitize($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 12px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مشخصات جنس (رنگ، مدل، سریال):</label>
                <input type="text" name="specifications" class="form-control" placeholder="مشخصات ظاهری و فنی">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">تعداد (عدد): <span style="color: #ef4444;">*</span></label>
                    <input type="number" name="quantity" class="form-control" min="1" value="1" required>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نرخ خرید (افغانی): <span style="color: #ef4444;">*</span></label>
                    <input type="number" step="any" name="purchase_price" class="form-control" min="0" required>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نرخ فروش (افغانی):</label>
                    <input type="number" step="any" name="sale_price" class="form-control" min="0">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">موقعیت در گدام:</label>
                    <input type="text" name="warehouse_location" class="form-control" placeholder="قفسه، الماری...">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">تاریخ خریداری:</label>
                    <input type="date" name="purchase_date" class="form-control" value="<?= date('Y-m-d') ?>">
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 8px;">
                <button type="button" onclick="document.getElementById('addStockModal').style.display='none'" class="btn btn-secondary">
                    انصراف
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus ml-1"></i> افزودن جنس به گدام
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 3: RECORD SALES PROGRESS -->
<div id="progressModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 16px;">
    <div style="background: #ffffff; border-radius: 16px; max-width: 460px; width: 100%; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); padding: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="font-size: 15px; font-weight: 800; color: #0f172a; margin: 0;">
                <i class="fa-solid fa-chart-line text-primary ml-1"></i> ثبت دستی فروش و مفاد مضاربت
            </h3>
            <button type="button" onclick="document.getElementById('progressModal').style.display='none'" style="background: none; border: none; font-size: 18px; color: #64748b; cursor: pointer;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_progress">
            <input type="hidden" id="progress_contract_id" name="contract_id" value="">

            <div style="background: #f8fafc; padding: 10px; border-radius: 8px; margin-bottom: 14px; font-size: 13px; color: #475569;">
                قرارداد: <strong id="progress_project_title" style="color: #0284c7;"></strong>
            </div>

            <div class="form-group" style="margin-bottom: 12px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مبلغ فروش اضافه شده (افغانی):</label>
                <input type="number" step="any" min="0" name="add_sales" class="form-control" required placeholder="مثلاً: ۵۰,۰۰۰">
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مفاد خالص تحقق‌یافته از این فروش (افغانی):</label>
                <input type="number" step="any" min="0" name="add_profit" class="form-control" required placeholder="مثلاً: ۸,۰۰۰" style="color: #0284c7; font-weight: bold;">
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 8px;">
                <button type="button" onclick="document.getElementById('progressModal').style.display='none'" class="btn btn-secondary">
                    انصراف
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus ml-1"></i> افزودن به آمار فروش
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 4: PAYOUT TO PARTNER -->
<div id="payoutModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 16px;">
    <div style="background: #ffffff; border-radius: 16px; max-width: 460px; width: 100%; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); padding: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="font-size: 15px; font-weight: 800; color: #0f172a; margin: 0;">
                <i class="fa-solid fa-money-bill-wave text-success ml-1"></i> پرداخت و تسویه با شریک مضاربت
            </h3>
            <button type="button" onclick="document.getElementById('payoutModal').style.display='none'" style="background: none; border: none; font-size: 18px; color: #64748b; cursor: pointer;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="payout_partner">
            <input type="hidden" id="payout_contract_id" name="contract_id" value="">

            <div style="background: #f1f5f9; padding: 10px; border-radius: 8px; margin-bottom: 14px; font-size: 13px; color: #334155;">
                شریک: <strong id="payout_partner_name"></strong><br>
                <span style="font-size: 11.5px; color: #64748b;">
                    مانده سهم سود: <strong id="payout_rem_profit" style="color: #7e22ce;"></strong> افغانی | 
                    مانده اصل سرمایه: <strong id="payout_rem_cap" style="color: #166534;"></strong> افغانی
                </span>
            </div>

            <div class="form-group" style="margin-bottom: 12px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">پرداخت سود به شریک (افغانی):</label>
                <input type="number" step="any" min="0" id="payout_profit_inp" name="payout_profit" class="form-control" value="0">
            </div>

            <div class="form-group" style="margin-bottom: 14px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">استرداد / بازگرداندن اصل سرمایه (افغانی):</label>
                <input type="number" step="any" min="0" id="return_cap_inp" name="return_capital" class="form-control" value="0">
            </div>

            <div style="margin-bottom: 16px;">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; cursor: pointer;">
                    <input type="checkbox" name="mark_settled" value="1">
                    <span>قرارداد کاملاً تسویه و خاتمه یافته علامت‌گذاری شود</span>
                </label>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 8px;">
                <button type="button" onclick="document.getElementById('payoutModal').style.display='none'" class="btn btn-secondary">
                    انصراف
                </button>
                <button type="submit" class="btn btn-primary" style="background: #10b981; border-color: #10b981;">
                    <i class="fa-solid fa-check ml-1"></i> ثبت پرداخت وجه
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 5: EDIT MUDARABA CONTRACT -->
<div id="editContractModal" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; padding: 16px;">
    <div style="background: #ffffff; border-radius: 16px; max-width: 600px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); padding: 24px; position: relative;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px;">
            <h3 style="font-size: 16px; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-pen-to-square text-primary"></i> ویرایش قرارداد مضاربت
            </h3>
            <button type="button" onclick="closeEditContractModal();" style="background: none; border: none; font-size: 18px; color: #64748b; cursor: pointer;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="edit_contract">
            <input type="hidden" name="contract_id" id="edit_contract_id" value="0">

            <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">نام شریک (سرمایه‌گذار): <span style="color: #ef4444;">*</span></label>
                    <input type="text" name="partner_name" id="edit_c_partner_name" class="form-control" required>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">شماره تماس:</label>
                    <input type="text" name="phone" id="edit_c_phone" class="form-control">
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 12px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">شرح کالا و عنوان پروژه: <span style="color: #ef4444;">*</span></label>
                <input type="text" name="project_title" id="edit_c_project_title" class="form-control" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">کشور مبدا:</label>
                    <input type="text" name="country_source" id="edit_c_country_source" class="form-control">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">مقدار کل سرمایه (افغانی): <span style="color: #ef4444;">*</span></label>
                    <input type="number" step="any" name="capital_amount" id="edit_c_capital_amount" class="form-control" required>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">سهم مفاد شریک (٪):</label>
                    <input type="number" step="any" name="partner_profit_rate" id="edit_c_partner_rate" class="form-control" required oninput="document.getElementById('edit_c_shop_rate').value = Math.max(0, 100 - parseFloat(this.value || 0));">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">سهم مفاد دکان (٪):</label>
                    <input type="number" step="any" name="shop_profit_rate" id="edit_c_shop_rate" class="form-control" required>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">تاریخ شروع:</label>
                    <input type="date" name="start_date" id="edit_c_start_date" class="form-control">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">موعد تسویه:</label>
                    <input type="date" name="settlement_date" id="edit_c_settlement_date" class="form-control">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-weight: 700; font-size: 12.5px;">وضعیت قرارداد:</label>
                    <select name="status" id="edit_c_status" class="form-control">
                        <option value="active">جاری و فعال</option>
                        <option value="settled">تسویه شده</option>
                        <option value="cancelled">لغو شده</option>
                    </select>
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label class="form-label" style="font-weight: 700; font-size: 12.5px;">یادداشت و توضیحات:</label>
                <input type="text" name="notes" id="edit_c_notes" class="form-control">
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 8px;">
                <button type="button" onclick="closeEditContractModal();" class="btn btn-secondary">
                    انصراف
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-check ml-1"></i> ذخیره تغییرات
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditContractModal(data) {
    document.getElementById('edit_contract_id').value = data.id;
    document.getElementById('edit_c_partner_name').value = data.partner_name || '';
    document.getElementById('edit_c_phone').value = data.phone || '';
    document.getElementById('edit_c_project_title').value = data.project_title || '';
    document.getElementById('edit_c_country_source').value = data.country_source || '';
    document.getElementById('edit_c_capital_amount').value = data.capital_amount || 0;
    document.getElementById('edit_c_partner_rate').value = data.partner_profit_rate || 50;
    document.getElementById('edit_c_shop_rate').value = data.shop_profit_rate || 50;
    document.getElementById('edit_c_start_date').value = data.start_date || '';
    document.getElementById('edit_c_settlement_date').value = data.settlement_date || '';
    document.getElementById('edit_c_status').value = data.status || 'active';
    document.getElementById('edit_c_notes').value = data.notes || '';
    document.getElementById('editContractModal').style.display = 'flex';
}

function closeEditContractModal() {
    document.getElementById('editContractModal').style.display = 'none';
}

// Bulk Selection Logic for Mudaraba Contracts
function toggleAllMudaraba(headerMaster) {
    const checkboxes = document.querySelectorAll('.mudaraba-chk');
    checkboxes.forEach(cb => cb.checked = headerMaster.checked);
    updateMudarabaBulkBar();
}

function selectAllMudarabaRows(checkAll) {
    const checkboxes = document.querySelectorAll('.mudaraba-chk');
    checkboxes.forEach(cb => cb.checked = checkAll);
    const master = document.getElementById('selectAllMudarabaHeader');
    if (master) master.checked = checkAll;
    updateMudarabaBulkBar();
}

function updateMudarabaBulkBar() {
    const checkboxes = document.querySelectorAll('.mudaraba-chk:checked');
    const bar = document.getElementById('mudarabaBulkActionBar');
    const countText = document.getElementById('mudarabaSelectedCountText');
    const count = checkboxes.length;

    if (count > 0) {
        bar.style.display = 'block';
        countText.textContent = count.toLocaleString('fa-IR');
    } else {
        bar.style.display = 'none';
    }
}

function confirmBulkDeleteMudaraba() {
    const checkboxes = document.querySelectorAll('.mudaraba-chk:checked');
    if (checkboxes.length === 0) {
        alert('لطفاً حداقل یک قرارداد مضاربت را برای حذف انتخاب نمایید.');
        return;
    }

    if (!confirm(`آیا از حذف تعداد ${checkboxes.length} قرارداد مضاربت انتخاب شده به صورت گروهی اطمینان کامل دارید؟ اجناس گدام از این مضاربت‌ها جدا خواهند شد.`)) {
        return;
    }

    const container = document.getElementById('mudarabaBulkDeleteInputsContainer');
    container.innerHTML = '';
    checkboxes.forEach(cb => {
        const hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'selected_ids[]';
        hidden.value = cb.value;
        container.appendChild(hidden);
    });

    document.getElementById('mudarabaBulkDeleteForm').submit();
}

function toggleContractStock(contractId) {
    var row = document.getElementById('contract_stock_row_' + contractId);
    if (!row) return;
    if (row.style.display === 'none' || row.style.display === '') {
        row.style.display = 'table-row';
    } else {
        row.style.display = 'none';
    }
}

function recalcMudarabaCapital() {
    var qty = parseFloat(document.getElementById('m_quantity').value || 0);
    var buy = parseFloat(document.getElementById('m_purchase_price').value || 0);
    var exp = parseFloat(document.getElementById('m_expenses').value || 0);
    var total = qty * (buy + exp);
    if (total > 0) {
        document.getElementById('m_capital_amount').value = total;
    }
}

function openAddStockModal(contractId, partnerName, countrySource) {
    document.getElementById('add_stock_contract_id').value = contractId;
    document.getElementById('add_stock_partner_name').textContent = partnerName;
    document.getElementById('addStockModal').style.display = 'flex';
}

function openProgressModal(id, title) {
    document.getElementById('progress_contract_id').value = id;
    document.getElementById('progress_project_title').textContent = title;
    document.getElementById('progressModal').style.display = 'flex';
}

function openPayoutModal(id, partnerName, remProfit, remCap) {
    document.getElementById('payout_contract_id').value = id;
    document.getElementById('payout_partner_name').textContent = partnerName;
    document.getElementById('payout_rem_profit').textContent = remProfit.toLocaleString();
    document.getElementById('payout_rem_cap').textContent = remCap.toLocaleString();
    document.getElementById('payout_profit_inp').value = remProfit > 0 ? remProfit : 0;
    document.getElementById('payoutModal').style.display = 'flex';
}

// Auto open specific contract stock if requested via query param
<?php if (!empty($_GET['contract_id'])): ?>
window.addEventListener('DOMContentLoaded', function() {
    toggleContractStock(<?= (int)$_GET['contract_id'] ?>);
});
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
