<?php
/**
 * NiKXor - Mobile Shop Management System
 * Add Product to Stock / گدام
 * URL: http://localhost/nikxor/modules/stock_add.php
 */

$pageTitle = 'ثبت جنس جدید در گدام';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

// Fetch categories, partners & active mudaraba contracts for selection dropdowns
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
$partners = $pdo->query("SELECT * FROM partners WHERE status = 'active' ORDER BY name ASC")->fetchAll();
$mudarabaContracts = $pdo->query("SELECT id, partner_name, project_title FROM mudaraba_contracts WHERE status = 'active' ORDER BY id DESC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست، لطفاً فرم را مجدداً ارسال نمایید.';
    } else {
        $name              = trim($_POST['name'] ?? '');
        $categoryId        = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $specifications    = trim($_POST['specifications'] ?? '');
        $quantity          = (int)normalize_digits($_POST['quantity'] ?? '0');
        $purchasePrice     = (float)normalize_digits($_POST['purchase_price'] ?? '0');
        $salePrice         = (float)normalize_digits($_POST['sale_price'] ?? '0');
        $expenses          = (float)normalize_digits($_POST['expenses'] ?? '0');
        $barcode           = trim($_POST['barcode'] ?? '');
        $countryOfOrigin   = trim($_POST['country_of_origin'] ?? '');
        $supplierName      = trim($_POST['supplier_name'] ?? '');
        $warehouseLocation = trim($_POST['warehouse_location'] ?? '');
        $partnerId         = !empty($_POST['partner_id']) ? (int)$_POST['partner_id'] : null;
        $mudarabaId        = !empty($_POST['mudaraba_id']) ? (int)$_POST['mudaraba_id'] : null;
        $purchaseDate      = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : date('Y-m-d');
        $exactNow          = date('Y-m-d H:i:s');

        // Capital amount = (purchasePrice + expenses) * quantity
        $capitalAmount = ($purchasePrice + $expenses) * $quantity;

        if (empty($name)) {
            $error = 'لطفاً نام جنس را وارد نمایید.';
        } elseif ($quantity < 0) {
            $error = 'تعداد موجودی نمی تواند منفی باشد.';
        } elseif ($purchasePrice < 0) {
            $error = 'نرخ خریداری معتبر نیست.';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO stock 
                    (name, category_id, specifications, quantity, purchase_price, sale_price, expenses, barcode, country_of_origin, supplier_name, warehouse_location, capital_amount, partner_id, mudaraba_id, purchase_date, created_at) 
                    VALUES (:name, :cat_id, :spec, :qty, :buy, :sale, :exp, :barcode, :orig, :supp, :loc, :cap, :pid, :mid, :pdate, :cdate)");
                
                $stmt->execute([
                    ':name'    => $name,
                    ':cat_id'  => $categoryId,
                    ':spec'    => $specifications,
                    ':qty'     => $quantity,
                    ':buy'     => $purchasePrice,
                    ':sale'    => $salePrice,
                    ':exp'     => $expenses,
                    ':barcode' => $barcode,
                    ':orig'    => $countryOfOrigin,
                    ':supp'    => $supplierName,
                    ':loc'     => $warehouseLocation,
                    ':cap'     => $capitalAmount,
                    ':pid'     => $partnerId,
                    ':mid'     => $mudarabaId,
                    ':pdate'   => $purchaseDate,
                    ':cdate'   => $exactNow
                ]);


                $newId = $pdo->lastInsertId();
                if ($mudarabaId > 0 && $capitalAmount > 0) {
                    $pdo->prepare("UPDATE mudaraba_contracts SET capital_amount = capital_amount + :cap WHERE id = :mid")
                        ->execute([':cap' => $capitalAmount, ':mid' => $mudarabaId]);
                }
                log_activity($currentUser['id'], 'ثبت جنس جدید', "ثبت جنس «{$name}» به تعداد {$quantity} عدد در گدام");

                set_flash("جنس «{$name}» با موفقیت در گدام ثبت گردید.", 'success');
                redirect(BASE_URL . 'modules/stock.php');
            } catch (Exception $e) {
                $error = 'خطا در ذخیره جنس: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="card" style="max-width: 900px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-plus-circle ml-1"></i> فورمه ثبت جنس جدید در گدام
        </h3>
        <a href="<?= BASE_URL ?>modules/stock.php" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-arrow-right ml-1"></i> بازگشت به لست
        </a>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <span><?= sanitize($error) ?></span>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <?= csrf_field() ?>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <!-- Product Name -->
            <div class="form-group" style="grid-column: 1 / -1;">
                <label class="form-label" for="name">
                    اسم جنس: <span style="color: #ef4444;">*</span>
                </label>
                <input type="text" id="name" name="name" class="form-control" required 
                       value="<?= sanitize($_POST['name'] ?? '') ?>" 
                       placeholder="مثلاً: سامسونگ گلکسی A55 یا چارجر اورجینال 25W">
            </div>

            <!-- Category -->
            <div class="form-group">
                <label class="form-label" for="category_id">دسته بندی:</label>
                <div style="display: flex; gap: 6px;">
                    <select id="category_id" name="category_id" class="form-control">
                        <option value="">-- بدون دسته بندی --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= (isset($_POST['category_id']) && $_POST['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                                <?= sanitize($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <a href="<?= BASE_URL ?>modules/categories.php" class="btn btn-secondary" title="مدیریت دسته ها" target="_blank">
                        <i class="fa-solid fa-gear"></i>
                    </a>
                </div>
            </div>

            <!-- Warehouse Location -->
            <div class="form-group">
                <label class="form-label" for="warehouse_location" style="display: flex; justify-content: space-between; align-items: center;">
                    <span>موقعیت در گدام / دکان:</span>
                    <?php if (is_feature_locked('warehouse_position')): ?>
                        <span class="badge-lock-tag" onclick="showLockModal('warehouse_position', 'Warehouse/Shelf Position', 'موقعیت در گدام/دکان');" style="cursor: pointer; font-size: 10px; padding: 1px 6px;"><i class="fa-solid fa-lock text-amber-500"></i> قفل</span>
                    <?php endif; ?>
                </label>
                <input type="text" id="warehouse_location" name="warehouse_location" class="form-control" 
                       value="<?= sanitize($_POST['warehouse_location'] ?? '') ?>" 
                       placeholder="مثلاً: قفسه A، ویترین ۲، کشو ۱">
            </div>

            <!-- Specifications -->
            <div class="form-group" style="grid-column: 1 / -1;">
                <label class="form-label" for="specifications">مشخصات جنس (حافظه، رم، رنگ، سلامت بتری، کارتن و...):</label>
                <textarea id="specifications" name="specifications" class="form-control" rows="2" 
                          placeholder="مثلاً: 256GB / 8GB RAM - رنگ مشکی - سلامت بتری 100%"><?= sanitize($_POST['specifications'] ?? '') ?></textarea>
            </div>

            <!-- Quantity -->
            <div class="form-group">
                <label class="form-label" for="quantity">
                    تعداد موجودی (عدد): <span style="color: #ef4444;">*</span>
                </label>
                <input type="number" id="quantity" name="quantity" class="form-control numeric-input qty-input" min="0" required 
                       value="<?= sanitize($_POST['quantity'] ?? '1') ?>">
            </div>

            <!-- Purchase Price -->
            <div class="form-group">
                <label class="form-label" for="purchase_price">
                    نرخ خریداری فی دانه (افغانی): <span style="color: #ef4444;">*</span>
                </label>
                <input type="number" step="any" id="purchase_price" name="purchase_price" class="form-control numeric-input price-input" min="0" required 
                       value="<?= sanitize($_POST['purchase_price'] ?? '') ?>" placeholder="قیمت خرید">
            </div>

            <!-- Sale Price -->
            <div class="form-group">
                <label class="form-label" for="sale_price">نرخ پیشنهادی فروش فی دانه (افغانی):</label>
                <input type="number" step="any" id="sale_price" name="sale_price" class="form-control numeric-input" min="0" 
                       value="<?= sanitize($_POST['sale_price'] ?? '') ?>" placeholder="قیمت فروش در بل">
            </div>

            <!-- Expenses per item -->
            <div class="form-group">
                <label class="form-label" for="expenses">مصارف اضافی فی دانه (کرایه، گمرک، پرزه):</label>
                <input type="number" step="any" id="expenses" name="expenses" class="form-control numeric-input" min="0" 
                       value="<?= sanitize($_POST['expenses'] ?? '0') ?>" placeholder="مصارف سر جمع جنس">
            </div>

            <!-- Barcode / IMEI -->
            <div class="form-group">
                <label class="form-label" for="barcode">بارکد یا سریال / IMEI جنس:</label>
                <input type="text" id="barcode" name="barcode" class="form-control" 
                       value="<?= sanitize($_POST['barcode'] ?? '') ?>" placeholder="اسکن بارکد یا شماره سریال">
            </div>

            <!-- Country of Origin -->
            <div class="form-group">
                <label class="form-label" for="country_of_origin">کشور سازنده / مبدا (دوبی، چین، ایران...):</label>
                <input type="text" id="country_of_origin" name="country_of_origin" class="form-control" 
                       value="<?= sanitize($_POST['country_of_origin'] ?? '') ?>" placeholder="کشور سازنده (اختیاری)">
            </div>

            <!-- Supplier -->
            <div class="form-group">
                <label class="form-label" for="supplier_name">نام شرکت / تامین کننده:</label>
                <input type="text" id="supplier_name" name="supplier_name" class="form-control" 
                       value="<?= sanitize($_POST['supplier_name'] ?? '') ?>" placeholder="نام شرکت یا عمده فروش (اختیاری)">
            </div>

            <!-- Mudaraba Contract Link (حساب مضاربت) -->
            <div class="form-group" style="grid-column: 1 / -1; background: #f0fdf4; border: 1.5px dashed #86efac; padding: 12px; border-radius: 8px;">
                <label class="form-label" for="mudaraba_id" style="color: #047857; font-weight: 800; display: flex; align-items: center; gap: 6px;">
                    <i class="fa-solid fa-handshake-angle"></i> آیا این جنس از پول حساب مضاربت با شخص خاصی خریداری شده است؟
                </label>
                <select id="mudaraba_id" name="mudaraba_id" class="form-control" style="background: white; border-color: #86efac; font-weight: 600;">
                    <option value="">-- خیر، از سرمایه عمومی دکان خریداری شده --</option>
                    <?php foreach ($mudarabaContracts as $mc): ?>
                        <option value="<?= $mc['id'] ?>" <?= (isset($_POST['mudaraba_id']) && $_POST['mudaraba_id'] == $mc['id']) ? 'selected' : '' ?>>
                            حساب مضاربت با: <?= sanitize($mc['partner_name']) ?> (پروژه: <?= sanitize($mc['project_title']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <small style="color: #065f46; font-size: 11.5px; display: block; margin-top: 4px;">
                    * در صورت انتخاب، در گدام برچسب «حساب مضاربت با فلانی» می‌خورد و فروش آن خودبخود در حساب مضاربت ثبت می‌شود.
                </small>
            </div>

            <!-- Associated Partner -->
            <div class="form-group">
                <label class="form-label" for="partner_id">شریک دائمی دکان (در صورت شراکت عمومی):</label>
                <select id="partner_id" name="partner_id" class="form-control">
                    <option value="">-- سرمایه عمومی دکان --</option>
                    <?php foreach ($partners as $part): ?>
                        <option value="<?= $part['id'] ?>" <?= (isset($_POST['partner_id']) && $_POST['partner_id'] == $part['id']) ? 'selected' : '' ?>>
                            <?= sanitize($part['name']) ?> (<?= to_persian_num($part['share_percentage']) ?>٪ سهم)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Purchase Date -->
            <div class="form-group">
                <label class="form-label" for="purchase_date">تاریخ خریداری:</label>
                <input type="date" id="purchase_date" name="purchase_date" class="form-control" 
                       value="<?= sanitize($_POST['purchase_date'] ?? date('Y-m-d')) ?>">
            </div>
        </div>

        <div style="margin-top: 24px; display: flex; gap: 10px;">
            <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">
                <i class="fa-solid fa-floppy-disk"></i> ثبت در گدام
            </button>
            <a href="<?= BASE_URL ?>modules/stock.php" class="btn btn-secondary">انصراف</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
