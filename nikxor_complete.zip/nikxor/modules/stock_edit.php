<?php
/**
 * NiKXor - Mobile Shop Management System
 * Edit Product in Stock / گدام
 * URL: http://localhost/nikxor/modules/stock_edit.php?id=X
 */

$pageTitle = 'ویرایش مشخصات جنس در گدام';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM stock WHERE id = :id");
$stmt->execute([':id' => $id]);
$item = $stmt->fetch();

if (!$item) {
    set_flash('جنس مورد نظر در گدام یافت نشد.', 'danger');
    redirect(BASE_URL . 'modules/stock.php');
}

$error = '';
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
$partners = $pdo->query("SELECT * FROM partners WHERE status = 'active' ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی نشست، لطفاً دوباره ارسال کنید.';
    } else {
        $name              = trim($_POST['name'] ?? '');
        $categoryId        = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $specifications    = trim($_POST['specifications'] ?? '');
        $quantity          = (int)normalize_digits($_POST['quantity'] ?? '0');
        $purchasePrice     = (float)normalize_digits($_POST['purchase_price'] ?? '0');
        $expenses          = (float)normalize_digits($_POST['expenses'] ?? '0');
        $countryOfOrigin   = trim($_POST['country_of_origin'] ?? 'چین');
        $supplierName      = trim($_POST['supplier_name'] ?? '');
        $warehouseLocation = trim($_POST['warehouse_location'] ?? '');
        $partnerId         = !empty($_POST['partner_id']) ? (int)$_POST['partner_id'] : null;
        $purchaseDate      = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : date('Y-m-d');

        $capitalAmount = ($purchasePrice + $expenses) * $quantity;

        if (empty($name)) {
            $error = 'نام جنس نمی تواند خالی باشد.';
        } elseif ($quantity < 0) {
            $error = 'تعداد موجودی نامعتبر است.';
        } else {
            try {
                $updStmt = $pdo->prepare("UPDATE stock SET 
                    name = :name,
                    category_id = :cat_id,
                    specifications = :spec,
                    quantity = :qty,
                    purchase_price = :buy,
                    expenses = :exp,
                    country_of_origin = :orig,
                    supplier_name = :supp,
                    warehouse_location = :loc,
                    capital_amount = :cap,
                    partner_id = :pid,
                    purchase_date = :pdate
                    WHERE id = :id");

                $updStmt->execute([
                    ':name'   => $name,
                    ':cat_id' => $categoryId,
                    ':spec'   => $specifications,
                    ':qty'    => $quantity,
                    ':buy'    => $purchasePrice,
                    ':exp'    => $expenses,
                    ':orig'   => $countryOfOrigin,
                    ':supp'   => $supplierName,
                    ':loc'    => $warehouseLocation,
                    ':cap'    => $capitalAmount,
                    ':pid'    => $partnerId,
                    ':pdate'  => $purchaseDate,
                    ':id'     => $id
                ]);

                log_activity($currentUser['id'], 'ویرایش جنس', "ویرایش مشخصات جنس «{$name}» با شناسه {$id}");
                set_flash("مشخصات جنس «{$name}» با موفقیت به روز گردید.", 'success');
                redirect(BASE_URL . 'modules/stock.php');
            } catch (Exception $e) {
                $error = 'خطا در ویرایش: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="card" style="max-width: 900px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-pen-to-square ml-1"></i> ویرایش جنس: <?= sanitize($item['name']) ?>
        </h3>
        <a href="<?= BASE_URL ?>modules/stock.php" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-arrow-right ml-1"></i> بازگشت به لست
        </a>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <span><?= sanitize($error) ?></span>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <?= csrf_field() ?>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group" style="grid-column: 1 / -1;">
                <label class="form-label" for="name">اسم جنس: <span style="color: #ef4444;">*</span></label>
                <input type="text" id="name" name="name" class="form-control" required 
                       value="<?= sanitize($_POST['name'] ?? $item['name']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="category_id">دسته بندی:</label>
                <select id="category_id" name="category_id" class="form-control">
                    <option value="">-- بدون دسته بندی --</option>
                    <?php 
                    $selectedCat = $_POST['category_id'] ?? $item['category_id'];
                    foreach ($categories as $cat): 
                    ?>
                        <option value="<?= $cat['id'] ?>" <?= ($selectedCat == $cat['id']) ? 'selected' : '' ?>>
                            <?= sanitize($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label" for="warehouse_location">موقعیت در گدام / دکان:</label>
                <input type="text" id="warehouse_location" name="warehouse_location" class="form-control" 
                       value="<?= sanitize($_POST['warehouse_location'] ?? $item['warehouse_location']) ?>">
            </div>

            <div class="form-group" style="grid-column: 1 / -1;">
                <label class="form-label" for="specifications">مشخصات جنس:</label>
                <textarea id="specifications" name="specifications" class="form-control" rows="2"><?= sanitize($_POST['specifications'] ?? $item['specifications']) ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label" for="quantity">تعداد موجودی (عدد): <span style="color: #ef4444;">*</span></label>
                <input type="number" id="quantity" name="quantity" class="form-control numeric-input qty-input" min="0" required 
                       value="<?= sanitize($_POST['quantity'] ?? $item['quantity']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="purchase_price">نرخ خریداری فی دانه (افغانی): <span style="color: #ef4444;">*</span></label>
                <input type="number" step="any" id="purchase_price" name="purchase_price" class="form-control numeric-input price-input" min="0" required 
                       value="<?= sanitize($_POST['purchase_price'] ?? $item['purchase_price']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="expenses">مصارف اضافی فی دانه:</label>
                <input type="number" step="any" id="expenses" name="expenses" class="form-control numeric-input" min="0" 
                       value="<?= sanitize($_POST['expenses'] ?? $item['expenses']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="country_of_origin">کشور سازنده / مبدا:</label>
                <input type="text" id="country_of_origin" name="country_of_origin" class="form-control" 
                       value="<?= sanitize($_POST['country_of_origin'] ?? $item['country_of_origin']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="supplier_name">نام شرکت / تامین کننده:</label>
                <input type="text" id="supplier_name" name="supplier_name" class="form-control" 
                       value="<?= sanitize($_POST['supplier_name'] ?? $item['supplier_name']) ?>">
            </div>

            <div class="form-group">
                <label class="form-label" for="partner_id">شریک مرتبط:</label>
                <select id="partner_id" name="partner_id" class="form-control">
                    <option value="">-- سرمایه عمومی دکان --</option>
                    <?php 
                    $selectedPartner = $_POST['partner_id'] ?? $item['partner_id'];
                    foreach ($partners as $part): 
                    ?>
                        <option value="<?= $part['id'] ?>" <?= ($selectedPartner == $part['id']) ? 'selected' : '' ?>>
                            <?= sanitize($part['name']) ?> (<?= to_persian_num($part['share_percentage']) ?>٪ سهم)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label" for="purchase_date">تاریخ خریداری:</label>
                <input type="date" id="purchase_date" name="purchase_date" class="form-control" 
                       value="<?= sanitize($_POST['purchase_date'] ?? $item['purchase_date']) ?>">
            </div>
        </div>

        <div style="margin-top: 24px; display: flex; gap: 10px;">
            <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">
                <i class="fa-solid fa-check"></i> ذخیره تغییرات
            </button>
            <a href="<?= BASE_URL ?>modules/stock.php" class="btn btn-secondary">انصراف</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
